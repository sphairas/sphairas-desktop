package de.schulconnex;

import java.time.Instant;
import java.util.Locale;

/**
 *
 * @author boris
 */
public class APICall {

    public static String HEADER_LINE = "Start time\tThread\tMethod\tPath\tStatus\tExecution (ms)\tTotal (ms)\tTrace-Id";

    private final String method;
    private final String path;
    private final long totalTime;
    private final long execution;
    private final int status;
    private final String trace;
    private final long start;
    private final String thread;

    public APICall(long start, String method, String path, int code, long totalTime, long execution, String trace) {
        this.start = start;
        this.thread = Thread.currentThread().getName();
        this.method = method;
        this.path = path;
        this.status = code;
        this.totalTime = totalTime;
        this.execution = execution;
        this.trace = trace;
    }

    public long getStart() {
        return start;
    }

    public String getTrace() {
        return trace;
    }

    public String getThread() {
        return thread;
    }

    public String getMethod() {
        return method;
    }

    public String getPath() {
        return path;
    }

    public long getTotalTime() {
        return totalTime;
    }

    public long getExecution() {
        return execution;
    }

    public int getStatus() {
        return status;
    }

    public String getTraceId() {
        return trace;
    }

    public String toLine() {
        return String.format(Locale.getDefault(), "%s\t%s\t%s\t%s\t%d\t%d\t%d\t%s", Instant.ofEpochMilli(start), thread, method, path, status, execution, totalTime, trace);
    }
}
