package de.schulconnex;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.*;
import java.time.OffsetDateTime;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.hc.client5.http.cookie.BasicCookieStore;
import org.apache.hc.client5.http.cookie.Cookie;
import org.apache.hc.client5.http.entity.UrlEncodedFormEntity;
import org.apache.hc.client5.http.entity.mime.MultipartEntityBuilder;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.cookie.BasicClientCookie;
import org.apache.hc.client5.http.protocol.HttpClientContext;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.Header;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.HttpResponse;
import org.apache.hc.core5.http.HttpStatus;
import org.apache.hc.core5.http.NameValuePair;
import org.apache.hc.core5.http.ParseException;
import org.apache.hc.core5.http.io.entity.ByteArrayEntity;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.http.io.entity.FileEntity;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.apache.hc.core5.http.io.support.ClassicRequestBuilder;
import org.apache.hc.core5.http.message.BasicNameValuePair;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.HashMap;
import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.net.URLEncoder;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.charset.UnsupportedCharsetException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.nio.file.Paths;
import java.lang.reflect.Type;
import java.net.URI;
import java.text.DateFormat;
import de.schulconnex.auth.Authentication;
import de.schulconnex.auth.HttpTokenAuth;
import de.schulconnex.qs.model.SanisExceptionDetails;
import java.util.Collections;
import java.util.Random;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.hc.client5.http.classic.ExecChain;
import org.apache.hc.client5.http.classic.ExecChainHandler;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.cookie.CookieStore;
import org.apache.hc.client5.http.cookie.StandardCookieSpec;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.core5.http.ClassicHttpRequest;
import org.apache.hc.core5.http.ClassicHttpResponse;
import org.apache.hc.core5.http.HttpException;
import org.apache.hc.core5.http.ProtocolException;
import org.openapitools.jackson.nullable.JsonNullableModule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2024-04-05T18:25:56.866712+02:00[Europe/Berlin]", comments = "Generator version: 7.4.0")
public class ApiClient extends JavaTimeFormatter {

    static final String X_SESSION_ID = "X-Session-ID";

    private static final Logger LOGGER = LoggerFactory.getLogger(ApiClient.class);

    private Map<String, String> defaultHeaderMap = new HashMap<>();
    private Map<String, String> defaultCookieMap = new HashMap<>();
    private final String basePath;
    private boolean debugging = false;
    private int connectionTimeout = 0;

    private final CloseableHttpClient httpClient;
    private ObjectMapper objectMapper;
    protected String tempFolderPath = null;

    private Map<String, Authentication> authentications;

    private int statusCode;
    private Map<String, List<String>> responseHeaders;
    private String url;

    private DateFormat dateFormat;

    private final Random random;
    private static ThreadLocal<Long> execStarts = new ThreadLocal<>();
    private final List<APICall> apiCalls = new ArrayList<>();

//    private Cookie session;
    private final AtomicReference<String> sessionHeader = new AtomicReference<>();

    // Methods that can have a request body
    private static List<String> bodyMethods = Arrays.asList("POST", "PUT", "DELETE", "PATCH");

    public ApiClient(CloseableHttpClient httpClient, String basePath) {
//        this.httpClient = HttpClientBuilder.create()
//                .addRequestInterceptorLast(new HttpRequestInterceptor() {
//                    @Override
//                    public void process(org.apache.hc.core5.http.HttpRequest request, EntityDetails entity, HttpContext context) throws HttpException, IOException {
//                        request.removeHeaders("Connection");
//                        request.removeHeaders("Accept-Encoding");
//                    }
//                })
//                .build();
        this.httpClient = httpClient;
        this.basePath = basePath;
        objectMapper = new ObjectMapper();
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(DeserializationFeature.FAIL_ON_INVALID_SUBTYPE, false);
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        objectMapper.enable(SerializationFeature.WRITE_ENUMS_USING_TO_STRING);
        objectMapper.enable(DeserializationFeature.READ_ENUMS_USING_TO_STRING);
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.registerModule(new JsonNullableModule());
        objectMapper.setDateFormat(ApiClient.buildDefaultDateFormat());

        dateFormat = ApiClient.buildDefaultDateFormat();

        // Set default User-Agent.
        setUserAgent("Schulconnex QS-API-Client");

        // Setup authentications (key: authentication name, value: authentication).
        authentications = new HashMap<>();
        authentications.put("token", new HttpTokenAuth());
        // Prevent the authentications from being modified.
        authentications = Collections.unmodifiableMap(authentications);

        random = new Random();
    }

    public ApiClient(String basePath) {
        this(HttpClients.createDefault(), basePath);
    }

    public static ApiClient create(final int syncConcurrent, String basePath) {
        class StartExecHandler implements ExecChainHandler {

            @Override
            public ClassicHttpResponse execute(ClassicHttpRequest request, ExecChain.Scope scope, ExecChain chain) throws IOException, HttpException {
                
                execStarts.set(System.currentTimeMillis());
                return chain.proceed(request, scope);
            }

        }
        CookieStore cookieStore = new BasicCookieStore();
        RequestConfig globalConfig = RequestConfig.custom().setCookieSpec(StandardCookieSpec.RELAXED).build();
        final PoolingHttpClientConnectionManager pcm = PoolingHttpClientConnectionManagerBuilder.create()
                .setMaxConnTotal(syncConcurrent)
                .setMaxConnPerRoute(syncConcurrent)
                .build();
        CloseableHttpClient client = HttpClients.custom()
                .setConnectionManager(pcm)
                .setDefaultCookieStore(cookieStore)
                .setDefaultRequestConfig(globalConfig)
                .addExecInterceptorLast("set.start-time", new StartExecHandler())
                .build();
        return new ApiClient(client, basePath);
    }

    public static DateFormat buildDefaultDateFormat() {
        return new RFC3339DateFormat();
    }

    /**
     * Returns the current object mapper used for JSON
     * serialization/deserialization.
     * <p>
     * Note: If you make changes to the object mapper, remember to set it back
     * via <code>setObjectMapper</code> in order to trigger HTTP client
     * rebuilding.
     * </p>
     *
     * @return Object mapper
     */
    public ObjectMapper getObjectMapper() {
        return objectMapper;
    }

    /**
     * Sets the object mapper.
     *
     * @param objectMapper object mapper
     * @return API client
     */
    public ApiClient setObjectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
        return this;
    }

    public CloseableHttpClient getHttpClient() {
        return httpClient;
    }

    public String getBasePath() {
        return basePath;
    }

    /**
     * Gets the status code of the previous request
     *
     * @return Status code
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * Gets the url of the previous request
     *
     * @return Status code
     */
    public String getUrl() {
        return url;
    }

    public void resetAPICalls() {
        apiCalls.clear();
    }

    public List<APICall> getApiCalls() {
        return apiCalls;
    }

    /**
     * Gets the response headers of the previous request
     *
     * @return Response headers
     */
    public Map<String, List<String>> getResponseHeaders() {
        return responseHeaders;
    }

    /**
     * Get authentications (key: authentication name, value: authentication).
     *
     * @return Map of authentication
     */
    public Map<String, Authentication> getAuthentications() {
        return authentications;
    }

    /**
     * Get authentication for the given name.
     *
     * @param authName The authentication name
     * @return The authentication, null if not found
     */
    public <A extends Authentication> A getAuthentication(String authName, Class<A> type) {
        return type.cast(authentications.get(authName));
    }

    /**
     * The path of temporary folder used to store downloaded files from
     * endpoints with file response. The default value is <code>null</code>,
     * i.e. using the system's default temporary folder.
     *
     * @return Temp folder path
     */
    public String getTempFolderPath() {
        return tempFolderPath;
    }

    /**
     * Set the User-Agent header's value (by adding to the default header map).
     *
     * @param userAgent User agent
     * @return API client
     */
    public ApiClient setUserAgent(String userAgent) {
        addDefaultHeader("User-Agent", userAgent);
        return this;
    }

    /**
     * Set temp folder path
     *
     * @param tempFolderPath Temp folder path
     * @return API client
     */
    public ApiClient setTempFolderPath(String tempFolderPath) {
        this.tempFolderPath = tempFolderPath;
        return this;
    }

    /**
     * Add a default header.
     *
     * @param key The header's key
     * @param value The header's value
     * @return API client
     */
    public ApiClient addDefaultHeader(String key, String value) {
        defaultHeaderMap.put(key, value);
        return this;
    }

    /**
     * Add a default cookie.
     *
     * @param key The cookie's key
     * @param value The cookie's value
     * @return API client
     */
    public ApiClient addDefaultCookie(String key, String value) {
        defaultCookieMap.put(key, value);
        return this;
    }

    /**
     * Check that whether debugging is enabled for this API client.
     *
     * @return True if debugging is on
     */
    public boolean isDebugging() {
        return debugging;
    }

    /**
     * Enable/disable debugging for this API client.
     *
     * @param debugging To enable (true) or disable (false) debugging
     * @return API client
     */
    public ApiClient setDebugging(boolean debugging) {
        // TODO: implement debugging mode
        this.debugging = debugging;
        return this;
    }

    /**
     * Connect timeout (in milliseconds).
     *
     * @return Connection timeout
     */
    public int getConnectTimeout() {
        return connectionTimeout;
    }

    /**
     * Set the connect timeout (in milliseconds). A value of 0 means no timeout,
     * otherwise values must be between 1 and {@link Integer#MAX_VALUE}.
     *
     * @param connectionTimeout Connection timeout in milliseconds
     * @return API client
     */
    public ApiClient setConnectTimeout(int connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
        return this;
    }

    /**
     * Get the date format used to parse/format date parameters.
     *
     * @return Date format
     */
    public DateFormat getDateFormat() {
        return dateFormat;
    }

    /**
     * Set the date format used to parse/format date parameters.
     *
     * @param dateFormat Date format
     * @return API client
     */
    public ApiClient setDateFormat(DateFormat dateFormat) {
        this.dateFormat = dateFormat;
        // Also set the date format for model (de)serialization with Date properties.
        this.objectMapper.setDateFormat((DateFormat) dateFormat.clone());
        return this;
    }

    /**
     * Parse the given string into Date object.
     *
     * @param str String
     * @return Date
     */
    public Date parseDate(String str) {
        try {
            return dateFormat.parse(str);
        } catch (java.text.ParseException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Format the given Date object into string.
     *
     * @param date Date
     * @return Date in string format
     */
    public String formatDate(Date date) {
        return dateFormat.format(date);
    }

    /**
     * Format the given parameter object into string.
     *
     * @param param Object
     * @return Object in string format
     */
    public String parameterToString(Object param) {
        if (param == null) {
            return "";
        } else if (param instanceof Date) {
            return formatDate((Date) param);
        } else if (param instanceof OffsetDateTime) {
            return formatOffsetDateTime((OffsetDateTime) param);
        } else if (param instanceof Collection) {
            StringBuilder b = new StringBuilder();
            for (Object o : (Collection<?>) param) {
                if (b.length() > 0) {
                    b.append(',');
                }
                b.append(String.valueOf(o));
            }
            return b.toString();
        } else {
            return String.valueOf(param);
        }
    }

    /**
     * Formats the specified query parameter to a list containing a single
     * {@code Pair} object.
     *
     * Note that {@code value} must not be a collection.
     *
     * @param name The name of the parameter.
     * @param value The value of the parameter.
     * @return A list containing a single {@code Pair} object.
     */
    public List<Pair> parameterToPair(String name, Object value) {
        List<Pair> params = new ArrayList<Pair>();

        // preconditions
        if (name == null || name.isEmpty() || value == null || value instanceof Collection) {
            return params;
        }

        params.add(new Pair(name, escapeString(parameterToString(value))));
        return params;
    }

    /**
     * Formats the specified collection query parameters to a list of
     * {@code Pair} objects.
     *
     * Note that the values of each of the returned Pair objects are
     * percent-encoded.
     *
     * @param collectionFormat The collection format of the parameter.
     * @param name The name of the parameter.
     * @param value The value of the parameter.
     * @return A list of {@code Pair} objects.
     */
    public List<Pair> parameterToPairs(String collectionFormat, String name, Collection value) {
        List<Pair> params = new ArrayList<Pair>();

        // preconditions
        if (name == null || name.isEmpty() || value == null || value.isEmpty()) {
            return params;
        }

        // create the params based on the collection format
        if ("multi".equals(collectionFormat)) {
            for (Object item : value) {
                params.add(new Pair(name, escapeString(parameterToString(item))));
            }
            return params;
        }

        // collectionFormat is assumed to be "csv" by default
        String delimiter = ",";

        // escape all delimiters except commas, which are URI reserved
        // characters
        if ("ssv".equals(collectionFormat)) {
            delimiter = escapeString(" ");
        } else if ("tsv".equals(collectionFormat)) {
            delimiter = escapeString("\t");
        } else if ("pipes".equals(collectionFormat)) {
            delimiter = escapeString("|");
        }

        StringBuilder sb = new StringBuilder();
        for (Object item : value) {
            sb.append(delimiter);
            sb.append(escapeString(parameterToString(item)));
        }

        params.add(new Pair(name, sb.substring(delimiter.length())));

        return params;
    }

    /**
     * Check if the given MIME is a JSON MIME. JSON MIME examples:
     * application/json application/json; charset=UTF8 APPLICATION/JSON
     * application/vnd.company+json
     *
     * @param mime MIME
     * @return True if MIME type is boolean
     */
    public boolean isJsonMime(String mime) {
        String jsonMime = "(?i)^(application/json|[^;/ \t]+/[^;/ \t]+[+]json)[ \t]*(;.*)?$";
        return mime != null && (mime.matches(jsonMime) || mime.equals("*/*"));
    }

    /**
     * Select the Accept header's value from the given accepts array: if JSON
     * exists in the given array, use it; otherwise use all of them (joining
     * into a string)
     *
     * @param accepts The accepts array to select from
     * @return The Accept header to use. If the given array is empty, null will
     * be returned (not to set the Accept header explicitly).
     */
    public String selectHeaderAccept(String[] accepts) {
        if (accepts.length == 0) {
            return null;
        }
        for (String accept : accepts) {
            if (isJsonMime(accept)) {
                return accept;
            }
        }
        return StringUtil.join(accepts, ",");
    }

    /**
     * Select the Content-Type header's value from the given array: if JSON
     * exists in the given array, use it; otherwise use the first one of the
     * array.
     *
     * @param contentTypes The Content-Type array to select from
     * @return The Content-Type header to use. If the given array is empty, or
     * matches "any", JSON will be used.
     */
    public String selectHeaderContentType(String[] contentTypes) {
        if (contentTypes.length == 0 || contentTypes[0].equals("*/*")) {
            return "application/json";
        }
        for (String contentType : contentTypes) {
            if (isJsonMime(contentType)) {
                return contentType;
            }
        }
        return contentTypes[0];
    }

    /**
     * Escape the given string to be used as URL query value.
     *
     * @param str String
     * @return Escaped string
     */
    public String escapeString(String str) {
        try {
            return URLEncoder.encode(str, "utf8").replaceAll("\\+", "%20");
        } catch (UnsupportedEncodingException e) {
            return str;
        }
    }

    /**
     * Transforms response headers into map.
     *
     * @param headers HTTP headers
     * @return a map of string array
     */
    protected Map<String, List<String>> transformResponseHeaders(Header[] headers) {
        Map<String, List<String>> headersMap = new HashMap<>();
        for (Header header : headers) {
            List<String> valuesList = headersMap.get(header.getName());
            if (valuesList != null) {
                valuesList.add(header.getValue());
            } else {
                valuesList = new ArrayList<>();
                valuesList.add(header.getValue());
                headersMap.put(header.getName(), valuesList);
            }
        }
        return headersMap;
    }

    /**
     * Parse content type object from header value
     */
    private ContentType getContentType(String headerValue) throws ApiException {
        try {
            return ContentType.parse(headerValue);
        } catch (UnsupportedCharsetException e) {
            throw new ApiException("Could not parse content type " + headerValue);
        }
    }

    /**
     * Get content type of a response or null if one was not provided
     */
    private String getResponseMimeType(HttpResponse response) throws ApiException {
        Header contentTypeHeader = response.getFirstHeader("Content-Type");
        if (contentTypeHeader != null) {
            return getContentType(contentTypeHeader.getValue()).getMimeType();
        }
        return null;
    }

    /**
     * Serialize the given Java object into string according the given
     * Content-Type (only JSON is supported for now).
     *
     * @param obj Object
     * @param contentType Content type
     * @param formParams Form parameters
     * @return Object
     * @throws ApiException API exception
     */
    public HttpEntity serialize(Object obj, Map<String, Object> formParams, ContentType contentType) throws ApiException {
        String mimeType = contentType.getMimeType();
        if (isJsonMime(mimeType)) {
            try {
                return new StringEntity(objectMapper.writeValueAsString(obj), contentType.withCharset(StandardCharsets.UTF_8));
            } catch (JsonProcessingException e) {
                throw new ApiException(e);
            }
        } else if (mimeType.equals(ContentType.MULTIPART_FORM_DATA.getMimeType())) {
            MultipartEntityBuilder multiPartBuilder = MultipartEntityBuilder.create();
            for (Entry<String, Object> paramEntry : formParams.entrySet()) {
                Object value = paramEntry.getValue();
                if (value instanceof File) {
                    multiPartBuilder.addBinaryBody(paramEntry.getKey(), (File) value);
                } else if (value instanceof byte[]) {
                    multiPartBuilder.addBinaryBody(paramEntry.getKey(), (byte[]) value);
                } else {
                    Charset charset = contentType.getCharset();
                    if (charset != null) {
                        ContentType customContentType = ContentType.create(ContentType.TEXT_PLAIN.getMimeType(), charset);
                        multiPartBuilder.addTextBody(paramEntry.getKey(), parameterToString(paramEntry.getValue()),
                                customContentType);
                    } else {
                        multiPartBuilder.addTextBody(paramEntry.getKey(), parameterToString(paramEntry.getValue()));
                    }
                }
            }
            return multiPartBuilder.build();
        } else if (mimeType.equals(ContentType.APPLICATION_FORM_URLENCODED.getMimeType())) {
            List<NameValuePair> formValues = new ArrayList<>();
            for (Entry<String, Object> paramEntry : formParams.entrySet()) {
                formValues.add(new BasicNameValuePair(paramEntry.getKey(), parameterToString(paramEntry.getValue())));
            }
            return new UrlEncodedFormEntity(formValues, contentType.getCharset());
        } else {
            // Handle files with unknown content type
            if (obj instanceof File) {
                return new FileEntity((File) obj, contentType);
            } else if (obj instanceof byte[]) {
                return new ByteArrayEntity((byte[]) obj, contentType);
            }
            throw new ApiException("Serialization for content type '" + contentType + "' not supported");
        }
    }

    /**
     * Deserialize response body to Java object according to the Content-Type.
     *
     * @param <T> Type
     * @param response Response
     * @param valueType Return type
     * @return Deserialized object
     * @throws ApiException API exception
     * @throws IOException IO exception
     */
    @SuppressWarnings("unchecked")
    public <T> T deserialize(CloseableHttpResponse response, TypeReference<T> valueType) throws ApiException, IOException, ParseException {
        if (valueType == null) {
            return null;
        }
        HttpEntity entity = response.getEntity();
        Type valueRawType = valueType.getType();
        if (valueRawType.equals(byte[].class)) {
            return (T) EntityUtils.toByteArray(entity);
        } else if (valueRawType.equals(File.class)) {
            return (T) downloadFileFromResponse(response);
        }
        String mimeType = getResponseMimeType(response);
        if (mimeType == null || isJsonMime(mimeType)) {
            // Assume json if no mime type
            // convert input stream to string
            String content = EntityUtils.toString(entity);

            if ("".equals(content)) { // returns null for empty body
                return null;
            }

            return objectMapper.readValue(content, valueType);
        } else if ("text/plain".equalsIgnoreCase(mimeType)) {
            // convert input stream to string
            return (T) EntityUtils.toString(entity);
        } else {
            throw new ApiException(
                    "Deserialization for content type '" + mimeType + "' not supported for type '" + valueType + "'",
                    response.getCode(),
                    responseHeaders,
                    EntityUtils.toString(entity)
            );
        }
    }

    private File downloadFileFromResponse(CloseableHttpResponse response) throws IOException {
        Header contentDispositionHeader = response.getFirstHeader("Content-Disposition");
        String contentDisposition = contentDispositionHeader == null ? null : contentDispositionHeader.getValue();
        File file = prepareDownloadFile(contentDisposition);
        Files.copy(response.getEntity().getContent(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
        return file;
    }

    protected File prepareDownloadFile(String contentDisposition) throws IOException {
        String filename = null;
        if (contentDisposition != null && !"".equals(contentDisposition)) {
            // Get filename from the Content-Disposition header.
            Pattern pattern = Pattern.compile("filename=['\"]?([^'\"\\s]+)['\"]?");
            Matcher matcher = pattern.matcher(contentDisposition);
            if (matcher.find()) {
                filename = matcher.group(1);
            }
        }

        String prefix;
        String suffix = null;
        if (filename == null) {
            prefix = "download-";
            suffix = "";
        } else {
            int pos = filename.lastIndexOf('.');
            if (pos == -1) {
                prefix = filename + "-";
            } else {
                prefix = filename.substring(0, pos) + "-";
                suffix = filename.substring(pos);
            }
            // Files.createTempFile requires the prefix to be at least three characters long
            if (prefix.length() < 3) {
                prefix = "download-";
            }
        }

        if (tempFolderPath == null) {
            return Files.createTempFile(prefix, suffix).toFile();
        } else {
            return Files.createTempFile(Paths.get(tempFolderPath), prefix, suffix).toFile();
        }
    }

    /**
     * Build full URL by concatenating base path, the given sub path and query
     * parameters.
     *
     * @param path The sub path
     * @param queryParams The query parameters
     * @param collectionQueryParams The collection query parameters
     * @param urlQueryDeepObject URL query string of the deep object parameters
     * @return The full URL
     */
    private String buildUrl(String path, List<Pair> queryParams, List<Pair> collectionQueryParams, String urlQueryDeepObject) {
        final String baseURL = basePath;

        final StringBuilder url = new StringBuilder();
        url.append(baseURL).append(path);

        if (queryParams != null && !queryParams.isEmpty()) {
            // support (constant) query string in `path`, e.g. "/posts?draft=1"
            String prefix = path.contains("?") ? "&" : "?";
            for (Pair param : queryParams) {
                if (param.getValue() != null) {
                    if (prefix != null) {
                        url.append(prefix);
                        prefix = null;
                    } else {
                        url.append("&");
                    }
                    String value = parameterToString(param.getValue());
                    // query parameter value already escaped as part of parameterToPair
                    url.append(escapeString(param.getName())).append("=").append(value);
                }
            }
        }

        if (collectionQueryParams != null && !collectionQueryParams.isEmpty()) {
            String prefix = url.toString().contains("?") ? "&" : "?";
            for (Pair param : collectionQueryParams) {
                if (param.getValue() != null) {
                    if (prefix != null) {
                        url.append(prefix);
                        prefix = null;
                    } else {
                        url.append("&");
                    }
                    String value = parameterToString(param.getValue());
                    // collection query parameter value already escaped as part of parameterToPairs
                    url.append(escapeString(param.getName())).append("=").append(value);
                }
            }
        }

        if (urlQueryDeepObject != null && urlQueryDeepObject.length() > 0) {
            url.append(url.toString().contains("?") ? "&" : "?");
            url.append(urlQueryDeepObject);
        }

        return url.toString();
    }

    protected boolean isSuccessfulStatus(int statusCode) {
        return statusCode >= 200 && statusCode < 300;
    }

    protected boolean isBodyAllowed(String method) {
        return bodyMethods.contains(method);
    }

    protected Cookie buildCookie(String key, String value, URI uri) {
        BasicClientCookie cookie = new BasicClientCookie(key, value);
        cookie.setDomain(uri.getHost());
        cookie.setPath("/");
        return cookie;
    }

    protected <T> T processResponse(CloseableHttpResponse response, TypeReference<T> returnType, String url) throws ApiException, IOException, ParseException {
        statusCode = response.getCode();
        if (statusCode == HttpStatus.SC_NO_CONTENT) {
            return null;
        }

        this.url = url;
        responseHeaders = transformResponseHeaders(response.getHeaders());
        if (isSuccessfulStatus(statusCode)) {
            return deserialize(response, returnType);
        } else {
            String mimeType = getResponseMimeType(response);
            String message = EntityUtils.toString(response.getEntity());
            if ((mimeType == null || isJsonMime(mimeType)) && !message.isEmpty()) {
                try {
                    TypeReference<SanisExceptionDetails> exceptionType = new TypeReference<SanisExceptionDetails>() {
                    };
                    SanisExceptionDetails details = objectMapper.readValue(message, exceptionType);
                    throw new ApiException(message, statusCode, responseHeaders, details);
                } catch (JsonProcessingException ex) {
                    throw new ApiException(ex);
                }
            }
            throw new ApiException(message, statusCode, responseHeaders, message);
        }
    }

    /**
     * Invoke API by sending HTTP request with the given options.
     *
     * @param <T> Type
     * @param path The sub-path of the HTTP URL
     * @param method The request method, one of "GET", "POST", "PUT", and
     * "DELETE"
     * @param queryParams The query parameters
     * @param collectionQueryParams The collection query parameters
     * @param urlQueryDeepObject A URL query string for deep object parameters
     * @param body The request body object - if it is not binary, otherwise null
     * @param headerParams The header parameters
     * @param cookieParams The cookie parameters
     * @param formParams The form parameters
     * @param accept The request's Accept header
     * @param contentType The request's Content-Type header
     * @param authNames The authentications to apply
     * @param returnType Return type
     * @return The response body in type of string
     * @throws ApiException API exception
     */
    public <T> T invokeAPI(
            String path,
            String method,
            List<Pair> queryParams,
            List<Pair> collectionQueryParams,
            String urlQueryDeepObject,
            Object body,
            Map<String, String> headerParams,
            Map<String, String> cookieParams,
            Map<String, Object> formParams,
            String accept,
            String contentType,
            String[] authNames,
            TypeReference<T> returnType) throws ApiException {
        if (body != null && !formParams.isEmpty()) {
            throw new ApiException("Cannot have body and form params");
        }

        authNames = new String[]{"token"};//Openapi: Muss für jede Methode eine Auth gesetzt sein?
        updateParamsForAuth(authNames, queryParams, headerParams, cookieParams);
        final String urlString = buildUrl(path, queryParams, collectionQueryParams, urlQueryDeepObject);

        ClassicRequestBuilder builder = ClassicRequestBuilder.create(method);
        builder.setUri(urlString);

        if (accept != null) {
            builder.addHeader("Accept", accept);
        }
        for (Entry<String, String> keyValue : headerParams.entrySet()) {
            builder.addHeader(keyValue.getKey(), keyValue.getValue());
        }
        for (Map.Entry<String, String> keyValue : defaultHeaderMap.entrySet()) {
            if (!headerParams.containsKey(keyValue.getKey())) {
                builder.addHeader(keyValue.getKey(), keyValue.getValue());
            }
        }

        BasicCookieStore store = new BasicCookieStore();
        for (Entry<String, String> keyValue : cookieParams.entrySet()) {
            store.addCookie(buildCookie(keyValue.getKey(), keyValue.getValue(), builder.getUri()));
        }
        for (Entry<String, String> keyValue : defaultCookieMap.entrySet()) {
            if (!cookieParams.containsKey(keyValue.getKey())) {
                store.addCookie(buildCookie(keyValue.getKey(), keyValue.getValue(), builder.getUri()));
            }
        }

//        if (session != null && !session.isExpired(Instant.now().plusMillis(1000l))) {
//            store.addCookie(session);
//        }
        HttpClientContext context = HttpClientContext.create();
        context.setCookieStore(store);

        ContentType contentTypeObj = getContentType(contentType);
        if (body != null || !formParams.isEmpty()) {
            if (isBodyAllowed(method)) {
                // Add entity if we have content and a valid method
                builder.setEntity(serialize(body, formParams, contentTypeObj));
            } else {
                throw new ApiException("method " + method + " does not support a request body");
            }
        } else {
            // for empty body
            builder.setEntity(new StringEntity("", contentTypeObj));
        }

        final String trace = random.ints(97, 122 + 1)
                .limit(8)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();
        builder.addHeader("X-Trace-Id", trace);
        final String s = sessionHeader.get();
        if (s != null) {
            builder.addHeader(X_SESSION_ID, "Bearer " + s);
        }
        MDC.put("Trace-Id", trace);
        final long start = System.currentTimeMillis();
        CloseableHttpResponse response = null;
        try {
            response = httpClient.execute(builder.build(), context);
            final long now = System.currentTimeMillis();
            final long dur = now - ApiClient.execStarts.get();
            final long total = now - start;
            apiCalls.add(new APICall(start, method, path, response.getCode(), total, dur, trace));
            LOGGER.debug("Execution duration for {} {} was {} ms. Total time was {}. Trace-Id: {}", new Object[]{method, urlString, dur, total, trace});
            Header h = response.getHeader(X_SESSION_ID);
            if (h != null) {
                sessionHeader.compareAndSet(s, h.getValue());
            }
//            context.getCookieStore().getCookies().stream()
//                    .filter(c -> "AL_SESS-S".equals(c.getName()))
//                    .filter(c -> !c.equals(session))
//                    .findAny()
//                    .ifPresent(c -> {
//                        session = c;
//                    });
            return processResponse(response, returnType, urlString);
        } catch (IOException | ProtocolException e) {
            throw new ApiException(e);
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException ex) {
                LOGGER.error(ex.getLocalizedMessage(), ex);
            }
        }
    }

    /**
     * Update query and header parameters based on authentication settings.
     *
     * @param authNames The authentications to apply
     * @param queryParams Query parameters
     * @param headerParams Header parameters
     * @param cookieParams Cookie parameters
     */
    private void updateParamsForAuth(String[] authNames, List<Pair> queryParams, Map<String, String> headerParams, Map<String, String> cookieParams) throws ApiException {
        for (String authName : authNames) {
            Authentication auth = authentications.get(authName);
            if (auth == null) {
                throw new RuntimeException("Authentication undefined: " + authName);
            }
            try {
                auth.applyToParams(queryParams, headerParams, cookieParams);
            } catch (IOException ex) {
                throw new ApiException(ex);
            }
        }
    }
}
