package de.schulconnex;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author boris
 */
public class JSON {

    static final DateTimeFormatter LOESCHZEIT = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm'Z'");

    private JSON() {
    }

    public static class LoeschzeitSerializer extends JsonSerializer<ZonedDateTime> {

        @Override
        public void serialize(ZonedDateTime value, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
            if (value == null) {
                throw new IOException("OffsetDateTime argument is null.");
            }
            final ZonedDateTime utc = value.withZoneSameInstant(ZoneId.of("UTC"));
            final String format = LOESCHZEIT.format(utc);
            jsonGenerator.writeString(format);
        }
    }

    public static class LoeschzeitDeserializer extends JsonDeserializer<ZonedDateTime> {

        @Override
        public ZonedDateTime deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JacksonException {
            final String text = p.getText();
            final LocalDateTime utc = LocalDateTime.parse(text, LOESCHZEIT);
            final ZonedDateTime ret = ZonedDateTime.ofLocal(utc, ZoneId.of("UTC"), ZoneOffset.UTC);
            return ret.withZoneSameInstant(ZoneId.systemDefault());
        }

    }
}
