package de.schulconnex;

import com.fasterxml.jackson.core.type.TypeReference;
import de.schulconnex.qs.model.Beziehung;
import de.schulconnex.qs.model.BeziehungReadResponse;
import de.schulconnex.qs.model.Beziehungendatensatz;
import de.schulconnex.qs.model.DeleteRequest;
import de.schulconnex.qs.model.Gruppe;
import de.schulconnex.qs.model.Gruppendatensatz;
import de.schulconnex.qs.model.Gruppenzugehoerigkeit;
import de.schulconnex.qs.model.Organisation;
import de.schulconnex.qs.model.Person;
import de.schulconnex.qs.model.Personendatensatz;
import de.schulconnex.qs.model.Personenkontext;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2024-04-05T18:25:56.866712+02:00[Europe/Berlin]", comments = "Generator version: 7.4.0")
public class SchulconnexQSApi {

    private ApiClient apiClient;

    public SchulconnexQSApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     *
     * Es wird eine neue Beziehung zu einem Personenkontext erstellt.
     *
     * @param personenkontextId (required)
     * @param beziehung (optional)
     * @return Beziehung
     * @throws ApiException if fails to make API call
     */
    public Beziehung createBeziehung(String personenkontextId, Beziehung beziehung) throws ApiException {
        return this.createBeziehung(personenkontextId, beziehung, Collections.emptyMap());
    }

    /**
     *
     * Es wird eine neue Beziehung zu einem Personenkontext erstellt.
     *
     * @param personenkontextId (required)
     * @param beziehung (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return Beziehung
     * @throws ApiException if fails to make API call
     */
    public Beziehung createBeziehung(String personenkontextId, Beziehung beziehung, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = beziehung;

        // verify the required parameter 'personenkontextId' is set
        if (personenkontextId == null) {
            throw new ApiException(400, "Missing the required parameter 'personenkontextId' when calling createBeziehung");
        }

        // create path and map variables
        String localVarPath = "/personenkontexte/{personenkontextId}/beziehungen"
                .replaceAll("\\{" + "personenkontextId" + "\\}", apiClient.escapeString(personenkontextId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Beziehung> localVarReturnType = new TypeReference<Beziehung>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "POST",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Es wird ein neuer Datensatz \&quot;Gruppe\&quot; erstellt.
     *
     * @param gruppe (optional)
     * @return Gruppe
     * @throws ApiException if fails to make API call
     */
    public Gruppe createGruppe(Gruppe gruppe) throws ApiException {
        return this.createGruppe(gruppe, Collections.emptyMap());
    }

    /**
     *
     * Es wird ein neuer Datensatz \&quot;Gruppe\&quot; erstellt.
     *
     * @param gruppe (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return Gruppe
     * @throws ApiException if fails to make API call
     */
    public Gruppe createGruppe(Gruppe gruppe, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = gruppe;

        // create path and map variables
        String localVarPath = "/gruppen";

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Gruppe> localVarReturnType = new TypeReference<Gruppe>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "POST",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Erstellt eine Gruppenzugehoerigkeit zur angegebenen Gruppe und dem
     * angegebenen Personenkontext.
     *
     * @param gruppenId (required)
     * @param gruppenzugehoerigkeit (optional)
     * @return Gruppenzugehoerigkeit
     * @throws ApiException if fails to make API call
     */
    public Gruppenzugehoerigkeit createGruppenzugehoerigkeit(String gruppenId, Gruppenzugehoerigkeit gruppenzugehoerigkeit) throws ApiException {
        return this.createGruppenzugehoerigkeit(gruppenId, gruppenzugehoerigkeit, Collections.emptyMap());
    }

    /**
     *
     * Erstellt eine Gruppenzugehoerigkeit zur angegebenen Gruppe und dem
     * angegebenen Personenkontext.
     *
     * @param gruppenId (required)
     * @param gruppenzugehoerigkeit (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return Gruppenzugehoerigkeit
     * @throws ApiException if fails to make API call
     */
    public Gruppenzugehoerigkeit createGruppenzugehoerigkeit(String gruppenId, Gruppenzugehoerigkeit gruppenzugehoerigkeit, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = gruppenzugehoerigkeit;

        // verify the required parameter 'gruppenId' is set
        if (gruppenId == null) {
            throw new ApiException(400, "Missing the required parameter 'gruppenId' when calling createGruppenzugehoerigkeit");
        }

        // create path and map variables
        String localVarPath = "/gruppen/{gruppenId}/gruppenzugehoerigkeiten"
                .replaceAll("\\{" + "gruppenId" + "\\}", apiClient.escapeString(gruppenId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Gruppenzugehoerigkeit> localVarReturnType = new TypeReference<Gruppenzugehoerigkeit>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "POST",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Es wird eine neue Person erstellt.
     *
     * @param person (optional)
     * @return Person
     * @throws ApiException if fails to make API call
     */
    public Person createPerson(Person person) throws ApiException {
        return this.createPerson(person, Collections.emptyMap());
    }

    /**
     *
     * Es wird eine neue Person erstellt.
     *
     * @param person (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return Person
     * @throws ApiException if fails to make API call
     */
    public Person createPerson(Person person, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = person;

        // create path and map variables
        String localVarPath = "/personen";

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Person> localVarReturnType = new TypeReference<Person>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "POST",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Erstellt einen Personenkontext zur angegebenen Person per ID.
     *
     * @param personId (required)
     * @param personenkontext (optional)
     * @return Personenkontext
     * @throws ApiException if fails to make API call
     */
    public Personenkontext createPersonenkontext(String personId, Personenkontext personenkontext) throws ApiException {
        return this.createPersonenkontext(personId, personenkontext, Collections.emptyMap());
    }

    /**
     *
     * Erstellt einen Personenkontext zur angegebenen Person per ID.
     *
     * @param personId (required)
     * @param personenkontext (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return Personenkontext
     * @throws ApiException if fails to make API call
     */
    public Personenkontext createPersonenkontext(String personId, Personenkontext personenkontext, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = personenkontext;

        // verify the required parameter 'personId' is set
        if (personId == null) {
            throw new ApiException(400, "Missing the required parameter 'personId' when calling createPersonenkontext");
        }

        // create path and map variables
        String localVarPath = "/personen/{personId}/personenkontexte"
                .replaceAll("\\{" + "personId" + "\\}", apiClient.escapeString(personId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Personenkontext> localVarReturnType = new TypeReference<Personenkontext>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "POST",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Löscht die Beziehung zur angeforderten ID.
     *
     * @param beziehungId (required)
     * @param deleteRequest (optional)
     * @throws ApiException if fails to make API call
     */
    public void deleteBeziehung(String beziehungId, DeleteRequest deleteRequest) throws ApiException {
        this.deleteBeziehung(beziehungId, deleteRequest, Collections.emptyMap());
    }

    /**
     *
     * Löscht die Beziehung zur angeforderten ID.
     *
     * @param beziehungId (required)
     * @param deleteRequest (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @throws ApiException if fails to make API call
     */
    public void deleteBeziehung(String beziehungId, DeleteRequest deleteRequest, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = deleteRequest;

        // verify the required parameter 'beziehungId' is set
        if (beziehungId == null) {
            throw new ApiException(400, "Missing the required parameter 'beziehungId' when calling deleteBeziehung");
        }

        // create path and map variables
        String localVarPath = "/beziehungen/{beziehungId}"
                .replaceAll("\\{" + "beziehungId" + "\\}", apiClient.escapeString(beziehungId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        apiClient.invokeAPI(
                localVarPath,
                "DELETE",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                null
        );
    }

    /**
     *
     * Löscht die Gruppe zur angegebenen ID.
     *
     * @param gruppenId (required)
     * @param deleteRequest (optional)
     * @throws ApiException if fails to make API call
     */
    public void deleteGruppe(String gruppenId, DeleteRequest deleteRequest) throws ApiException {
        this.deleteGruppe(gruppenId, deleteRequest, Collections.emptyMap());
    }

    /**
     *
     * Löscht die Gruppe zur angegebenen ID.
     *
     * @param gruppenId (required)
     * @param deleteRequest (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @throws ApiException if fails to make API call
     */
    public void deleteGruppe(String gruppenId, DeleteRequest deleteRequest, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = deleteRequest;

        // verify the required parameter 'gruppenId' is set
        if (gruppenId == null) {
            throw new ApiException(400, "Missing the required parameter 'gruppenId' when calling deleteGruppe");
        }

        // create path and map variables
        String localVarPath = "/gruppen/{gruppenId}"
                .replaceAll("\\{" + "gruppenId" + "\\}", apiClient.escapeString(gruppenId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        apiClient.invokeAPI(
                localVarPath,
                "DELETE",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                null
        );
    }

    /**
     *
     * Löscht die Gruppenzugehoerigkeit zur angeforderten ID.
     *
     * @param gruppenzugehoerigkeitId (required)
     * @param deleteRequest (optional)
     * @throws ApiException if fails to make API call
     */
    public void deleteGruppenzugehoerigkeit(String gruppenzugehoerigkeitId, DeleteRequest deleteRequest) throws ApiException {
        this.deleteGruppenzugehoerigkeit(gruppenzugehoerigkeitId, deleteRequest, Collections.emptyMap());
    }

    /**
     *
     * Löscht die Gruppenzugehoerigkeit zur angeforderten ID.
     *
     * @param gruppenzugehoerigkeitId (required)
     * @param deleteRequest (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @throws ApiException if fails to make API call
     */
    public void deleteGruppenzugehoerigkeit(String gruppenzugehoerigkeitId, DeleteRequest deleteRequest, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = deleteRequest;

        // verify the required parameter 'gruppenzugehoerigkeitId' is set
        if (gruppenzugehoerigkeitId == null) {
            throw new ApiException(400, "Missing the required parameter 'gruppenzugehoerigkeitId' when calling deleteGruppenzugehoerigkeit");
        }

        // create path and map variables
        String localVarPath = "/gruppenzugehoerigkeiten/{gruppenzugehoerigkeitId}"
                .replaceAll("\\{" + "gruppenzugehoerigkeitId" + "\\}", apiClient.escapeString(gruppenzugehoerigkeitId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        apiClient.invokeAPI(
                localVarPath,
                "DELETE",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                null
        );
    }

    /**
     *
     * Löscht die Person zur angeforderten ID.
     *
     * @param personId (required)
     * @param deleteRequest (optional)
     * @throws ApiException if fails to make API call
     */
    public void deletePerson(String personId, DeleteRequest deleteRequest) throws ApiException {
        this.deletePerson(personId, deleteRequest, Collections.emptyMap());
    }

    /**
     *
     * Löscht die Person zur angeforderten ID.
     *
     * @param personId (required)
     * @param deleteRequest (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @throws ApiException if fails to make API call
     */
    public void deletePerson(String personId, DeleteRequest deleteRequest, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = deleteRequest;

        // verify the required parameter 'personId' is set
        if (personId == null) {
            throw new ApiException(400, "Missing the required parameter 'personId' when calling deletePerson");
        }

        // create path and map variables
        String localVarPath = "/personen/{personId}"
                .replaceAll("\\{" + "personId" + "\\}", apiClient.escapeString(personId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        apiClient.invokeAPI(
                localVarPath,
                "DELETE",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                null
        );
    }

    /**
     *
     * Löscht den Personenkontext zur angeforderten ID.
     *
     * @param personenkontextId (required)
     * @param deleteRequest (optional)
     * @throws ApiException if fails to make API call
     */
    public void deletePersonenkontext(String personenkontextId, DeleteRequest deleteRequest) throws ApiException {
        this.deletePersonenkontext(personenkontextId, deleteRequest, Collections.emptyMap());
    }

    /**
     *
     * Löscht den Personenkontext zur angeforderten ID.
     *
     * @param personenkontextId (required)
     * @param deleteRequest (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @throws ApiException if fails to make API call
     */
    public void deletePersonenkontext(String personenkontextId, DeleteRequest deleteRequest, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = deleteRequest;

        // verify the required parameter 'personenkontextId' is set
        if (personenkontextId == null) {
            throw new ApiException(400, "Missing the required parameter 'personenkontextId' when calling deletePersonenkontext");
        }

        // create path and map variables
        String localVarPath = "/personenkontexte/{personenkontextId}"
                .replaceAll("\\{" + "personenkontextId" + "\\}", apiClient.escapeString(personenkontextId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        apiClient.invokeAPI(
                localVarPath,
                "DELETE",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                null
        );
    }

    /**
     *
     * Gibt die Informationen der anfordernden Organisation zurück.
     *
     * @return Organisation
     * @throws ApiException if fails to make API call
     */
    public Organisation getOrganisationInfo() throws ApiException {
        return this.getOrganisationInfo(Collections.emptyMap());
    }

    /**
     *
     * Gibt die Informationen der anfordernden Organisation zurück.
     *
     * @param additionalHeaders additionalHeaders for this call
     * @return Organisation
     * @throws ApiException if fails to make API call
     */
    public Organisation getOrganisationInfo(Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/organisation-info";

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Organisation> localVarReturnType = new TypeReference<Organisation>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Liefert den Gruppendatensatz zur angeforderten ID.
     *
     * @param gruppenId (required)
     * @return Gruppendatensatz
     * @throws ApiException if fails to make API call
     */
    public Gruppendatensatz readGruppe(String gruppenId) throws ApiException {
        return this.readGruppe(gruppenId, Collections.emptyMap());
    }

    /**
     *
     * Liefert den Gruppendatensatz zur angeforderten ID.
     *
     * @param gruppenId (required)
     * @param additionalHeaders additionalHeaders for this call
     * @return Gruppendatensatz
     * @throws ApiException if fails to make API call
     */
    public Gruppendatensatz readGruppe(String gruppenId, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // verify the required parameter 'gruppenId' is set
        if (gruppenId == null) {
            throw new ApiException(400, "Missing the required parameter 'gruppenId' when calling readGruppe");
        }

        // create path and map variables
        String localVarPath = "/gruppen/{gruppenId}"
                .replaceAll("\\{" + "gruppenId" + "\\}", apiClient.escapeString(gruppenId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Gruppendatensatz> localVarReturnType = new TypeReference<Gruppendatensatz>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Liefert die Gruppenzugehoerigkeit zur angeforderten ID.
     *
     * @param gruppenzugehoerigkeitId (required)
     * @return Gruppendatensatz
     * @throws ApiException if fails to make API call
     */
    public Gruppendatensatz readGruppenzugehoerigkeit(String gruppenzugehoerigkeitId) throws ApiException {
        return this.readGruppenzugehoerigkeit(gruppenzugehoerigkeitId, Collections.emptyMap());
    }

    /**
     *
     * Liefert die Gruppenzugehoerigkeit zur angeforderten ID.
     *
     * @param gruppenzugehoerigkeitId (required)
     * @param additionalHeaders additionalHeaders for this call
     * @return Gruppendatensatz
     * @throws ApiException if fails to make API call
     */
    public Gruppendatensatz readGruppenzugehoerigkeit(String gruppenzugehoerigkeitId, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // verify the required parameter 'gruppenzugehoerigkeitId' is set
        if (gruppenzugehoerigkeitId == null) {
            throw new ApiException(400, "Missing the required parameter 'gruppenzugehoerigkeitId' when calling readGruppenzugehoerigkeit");
        }

        // create path and map variables
        String localVarPath = "/gruppenzugehoerigkeiten/{gruppenzugehoerigkeitId}"
                .replaceAll("\\{" + "gruppenzugehoerigkeitId" + "\\}", apiClient.escapeString(gruppenzugehoerigkeitId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Gruppendatensatz> localVarReturnType = new TypeReference<Gruppendatensatz>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Gibt die Gruppenzugehoerigkeiten zur angeforderten Gruppe per ID zurück.
     *
     * @param gruppenId (required)
     * @param referrer (optional)
     * @param rollen (optional)
     * @return List&lt;Gruppenzugehoerigkeit&gt;
     * @throws ApiException if fails to make API call
     */
    public List<Gruppenzugehoerigkeit> readGruppenzugehoerigkeiten(String gruppenId, String referrer, String rollen) throws ApiException {
        return this.readGruppenzugehoerigkeiten(gruppenId, referrer, rollen, Collections.emptyMap());
    }

    /**
     *
     * Gibt die Gruppenzugehoerigkeiten zur angeforderten Gruppe per ID zurück.
     *
     * @param gruppenId (required)
     * @param referrer (optional)
     * @param rollen (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return List&lt;Gruppenzugehoerigkeit&gt;
     * @throws ApiException if fails to make API call
     */
    public List<Gruppenzugehoerigkeit> readGruppenzugehoerigkeiten(String gruppenId, String referrer, String rollen, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // verify the required parameter 'gruppenId' is set
        if (gruppenId == null) {
            throw new ApiException(400, "Missing the required parameter 'gruppenId' when calling readGruppenzugehoerigkeiten");
        }

        // create path and map variables
        String localVarPath = "/gruppen/{gruppenId}/gruppenzugehoerigkeiten"
                .replaceAll("\\{" + "gruppenId" + "\\}", apiClient.escapeString(gruppenId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarQueryParams.addAll(apiClient.parameterToPair("referrer", referrer));
        localVarQueryParams.addAll(apiClient.parameterToPair("rollen", rollen));

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<List<Gruppenzugehoerigkeit>> localVarReturnType = new TypeReference<List<Gruppenzugehoerigkeit>>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Liefert die Organisation zur angegebenen id.
     *
     * @param organisationsId (required)
     * @return Organisation
     * @throws ApiException if fails to make API call
     */
    public Organisation readOrganisation(String organisationsId) throws ApiException {
        return this.readOrganisation(organisationsId, Collections.emptyMap());
    }

    /**
     *
     * Liefert die Organisation zur angegebenen id.
     *
     * @param organisationsId (required)
     * @param additionalHeaders additionalHeaders for this call
     * @return Organisation
     * @throws ApiException if fails to make API call
     */
    public Organisation readOrganisation(String organisationsId, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // verify the required parameter 'organisationsId' is set
        if (organisationsId == null) {
            throw new ApiException(400, "Missing the required parameter 'organisationsId' when calling readOrganisation");
        }

        // create path and map variables
        String localVarPath = "/organisationen/{organisationsId}"
                .replaceAll("\\{" + "organisationsId" + "\\}", apiClient.escapeString(organisationsId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Organisation> localVarReturnType = new TypeReference<Organisation>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Liefert den Personendatensatz zur angeforderten ID.
     *
     * @param personId (required)
     * @return Personendatensatz
     * @throws ApiException if fails to make API call
     */
    public Personendatensatz readPerson(String personId) throws ApiException {
        return this.readPerson(personId, Collections.emptyMap());
    }

    /**
     *
     * Liefert den Personendatensatz zur angeforderten ID.
     *
     * @param personId (required)
     * @param additionalHeaders additionalHeaders for this call
     * @return Personendatensatz
     * @throws ApiException if fails to make API call
     */
    public Personendatensatz readPerson(String personId, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // verify the required parameter 'personId' is set
        if (personId == null) {
            throw new ApiException(400, "Missing the required parameter 'personId' when calling readPerson");
        }

        // create path and map variables
        String localVarPath = "/personen/{personId}"
                .replaceAll("\\{" + "personId" + "\\}", apiClient.escapeString(personId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Personendatensatz> localVarReturnType = new TypeReference<Personendatensatz>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Liefert den Personenkontext zur angeforderten ID.
     *
     * @param personenkontextId (required)
     * @return Personendatensatz
     * @throws ApiException if fails to make API call
     */
    public Personendatensatz readPersonenkontext(String personenkontextId) throws ApiException {
        return this.readPersonenkontext(personenkontextId, Collections.emptyMap());
    }

    /**
     *
     * Liefert den Personenkontext zur angeforderten ID.
     *
     * @param personenkontextId (required)
     * @param additionalHeaders additionalHeaders for this call
     * @return Personendatensatz
     * @throws ApiException if fails to make API call
     */
    public Personendatensatz readPersonenkontext(String personenkontextId, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // verify the required parameter 'personenkontextId' is set
        if (personenkontextId == null) {
            throw new ApiException(400, "Missing the required parameter 'personenkontextId' when calling readPersonenkontext");
        }

        // create path and map variables
        String localVarPath = "/personenkontexte/{personenkontextId}"
                .replaceAll("\\{" + "personenkontextId" + "\\}", apiClient.escapeString(personenkontextId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Personendatensatz> localVarReturnType = new TypeReference<Personendatensatz>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Gibt die Personenkontexte zur angeforderten Person per ID zurück.
     *
     * @param personId (required)
     * @param referrer (optional)
     * @param rolle (optional)
     * @param personenstatus (optional)
     * @param sichtfreigabe (optional)
     * @return List&lt;Personenkontext&gt;
     * @throws ApiException if fails to make API call
     */
    public List<Personenkontext> readPersonenkontexte(String personId, String referrer, String rolle, String personenstatus, String sichtfreigabe) throws ApiException {
        return this.readPersonenkontexte(personId, referrer, rolle, personenstatus, sichtfreigabe, Collections.emptyMap());
    }

    /**
     *
     * Gibt die Personenkontexte zur angeforderten Person per ID zurück.
     *
     * @param personId (required)
     * @param referrer (optional)
     * @param rolle (optional)
     * @param personenstatus (optional)
     * @param sichtfreigabe (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return List&lt;Personenkontext&gt;
     * @throws ApiException if fails to make API call
     */
    public List<Personenkontext> readPersonenkontexte(String personId, String referrer, String rolle, String personenstatus, String sichtfreigabe, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // verify the required parameter 'personId' is set
        if (personId == null) {
            throw new ApiException(400, "Missing the required parameter 'personId' when calling readPersonenkontexte");
        }

        // create path and map variables
        String localVarPath = "/personen/{personId}/personenkontexte"
                .replaceAll("\\{" + "personId" + "\\}", apiClient.escapeString(personId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarQueryParams.addAll(apiClient.parameterToPair("referrer", referrer));
        localVarQueryParams.addAll(apiClient.parameterToPair("rolle", rolle));
        localVarQueryParams.addAll(apiClient.parameterToPair("personenstatus", personenstatus));
        localVarQueryParams.addAll(apiClient.parameterToPair("sichtfreigabe", sichtfreigabe));

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<List<Personenkontext>> localVarReturnType = new TypeReference<List<Personenkontext>>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Liefert alle Gruppendatensätze zurück, auf die zugegriffen werden kann.
     *
     * @param referrer (optional)
     * @param bezeichnung (optional)
     * @param optionen (optional)
     * @param differenzierung (optional)
     * @param bildungsziele (optional)
     * @param jahrgangsstufen (optional)
     * @param faecher (optional)
     * @param sichtfreigabe (optional)
     * @return List&lt;Gruppendatensatz&gt;
     * @throws ApiException if fails to make API call
     */
    public List<Gruppendatensatz> searchGruppen(String referrer, String bezeichnung, String optionen, String differenzierung, String bildungsziele, String jahrgangsstufen, String faecher, String sichtfreigabe) throws ApiException {
        return this.searchGruppen(referrer, bezeichnung, optionen, differenzierung, bildungsziele, jahrgangsstufen, faecher, sichtfreigabe, Collections.emptyMap());
    }

    /**
     *
     * Liefert alle Gruppendatensätze zurück, auf die zugegriffen werden kann.
     *
     * @param referrer (optional)
     * @param bezeichnung (optional)
     * @param optionen (optional)
     * @param differenzierung (optional)
     * @param bildungsziele (optional)
     * @param jahrgangsstufen (optional)
     * @param faecher (optional)
     * @param sichtfreigabe (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return List&lt;Gruppendatensatz&gt;
     * @throws ApiException if fails to make API call
     */
    public List<Gruppendatensatz> searchGruppen(String referrer, String bezeichnung, String optionen, String differenzierung, String bildungsziele, String jahrgangsstufen, String faecher, String sichtfreigabe, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/gruppen";

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarQueryParams.addAll(apiClient.parameterToPair("referrer", referrer));
        localVarQueryParams.addAll(apiClient.parameterToPair("bezeichnung", bezeichnung));
        localVarQueryParams.addAll(apiClient.parameterToPair("optionen", optionen));
        localVarQueryParams.addAll(apiClient.parameterToPair("differenzierung", differenzierung));
        localVarQueryParams.addAll(apiClient.parameterToPair("bildungsziele", bildungsziele));
        localVarQueryParams.addAll(apiClient.parameterToPair("jahrgangsstufen", jahrgangsstufen));
        localVarQueryParams.addAll(apiClient.parameterToPair("faecher", faecher));
        localVarQueryParams.addAll(apiClient.parameterToPair("sichtfreigabe", sichtfreigabe));

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<List<Gruppendatensatz>> localVarReturnType = new TypeReference<List<Gruppendatensatz>>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Liefert alle Personenkontexte zurück, auf die zugegriffen werden kann.
     *
     * @param referrer (optional)
     * @param rollen (optional)
     * @return List&lt;Gruppendatensatz&gt;
     * @throws ApiException if fails to make API call
     */
    public List<Gruppendatensatz> searchGruppenzugehoerigkeiten(String referrer, String rollen) throws ApiException {
        return this.searchGruppenzugehoerigkeiten(referrer, rollen, Collections.emptyMap());
    }

    /**
     *
     * Liefert alle Personenkontexte zurück, auf die zugegriffen werden kann.
     *
     * @param referrer (optional)
     * @param rollen (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return List&lt;Gruppendatensatz&gt;
     * @throws ApiException if fails to make API call
     */
    public List<Gruppendatensatz> searchGruppenzugehoerigkeiten(String referrer, String rollen, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/gruppenzugehoerigkeiten";

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarQueryParams.addAll(apiClient.parameterToPair("referrer", referrer));
        localVarQueryParams.addAll(apiClient.parameterToPair("rollen", rollen));

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<List<Gruppendatensatz>> localVarReturnType = new TypeReference<List<Gruppendatensatz>>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Liefert alle Organisationen zurück.
     *
     * @param kennung (optional)
     * @param name (optional)
     * @param typ (optional)
     * @return List&lt;Organisation&gt;
     * @throws ApiException if fails to make API call
     */
    public List<Organisation> searchOrganisationen(String kennung, String name, String typ) throws ApiException {
        return this.searchOrganisationen(kennung, name, typ, Collections.emptyMap());
    }

    /**
     *
     * Liefert alle Organisationen zurück.
     *
     * @param kennung (optional)
     * @param name (optional)
     * @param typ (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return List&lt;Organisation&gt;
     * @throws ApiException if fails to make API call
     */
    public List<Organisation> searchOrganisationen(String kennung, String name, String typ, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/organisationen";

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarQueryParams.addAll(apiClient.parameterToPair("kennung", kennung));
        localVarQueryParams.addAll(apiClient.parameterToPair("name", name));
        localVarQueryParams.addAll(apiClient.parameterToPair("typ", typ));

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<List<Organisation>> localVarReturnType = new TypeReference<List<Organisation>>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Liefert alle Personenkontexte zurück, auf die zugegriffen werden kann.
     *
     * @param referrer (optional)
     * @param rolle (optional)
     * @param personenstatus (optional)
     * @param sichtfreigabe (optional)
     * @return List&lt;Personendatensatz&gt;
     * @throws ApiException if fails to make API call
     */
    public List<Personendatensatz> searchPersonenkontexte(String referrer, String rolle, String personenstatus, String sichtfreigabe) throws ApiException {
        return this.searchPersonenkontexte(referrer, rolle, personenstatus, sichtfreigabe, Collections.emptyMap());
    }

    /**
     *
     * Liefert alle Personenkontexte zurück, auf die zugegriffen werden kann.
     *
     * @param referrer (optional)
     * @param rolle (optional)
     * @param personenstatus (optional)
     * @param sichtfreigabe (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return List&lt;Personendatensatz&gt;
     * @throws ApiException if fails to make API call
     */
    public List<Personendatensatz> searchPersonenkontexte(String referrer, String rolle, String personenstatus, String sichtfreigabe, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/personenkontexte";

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarQueryParams.addAll(apiClient.parameterToPair("referrer", referrer));
        localVarQueryParams.addAll(apiClient.parameterToPair("rolle", rolle));
        localVarQueryParams.addAll(apiClient.parameterToPair("personenstatus", personenstatus));
        localVarQueryParams.addAll(apiClient.parameterToPair("sichtfreigabe", sichtfreigabe));

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<List<Personendatensatz>> localVarReturnType = new TypeReference<List<Personendatensatz>>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Liefert alle Personendatensätze zurück, auf die zugegriffen werden kann.
     *
     * @param referrer (optional)
     * @param familienname (optional)
     * @param vorname (optional)
     * @param sichtfreigabe (optional)
     * @return List&lt;Personendatensatz&gt;
     * @throws ApiException if fails to make API call
     */
    public List<Personendatensatz> searchPersons(String referrer, String familienname, String vorname, String sichtfreigabe) throws ApiException {
        return this.searchPersons(referrer, familienname, vorname, sichtfreigabe, Collections.emptyMap());
    }

    /**
     *
     * Liefert alle Personendatensätze zurück, auf die zugegriffen werden kann.
     *
     * @param referrer (optional)
     * @param familienname (optional)
     * @param vorname (optional)
     * @param sichtfreigabe (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return List&lt;Personendatensatz&gt;
     * @throws ApiException if fails to make API call
     */
    public List<Personendatensatz> searchPersons(String referrer, String familienname, String vorname, String sichtfreigabe, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/personen";

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarQueryParams.addAll(apiClient.parameterToPair("referrer", referrer));
        localVarQueryParams.addAll(apiClient.parameterToPair("familienname", familienname));
        localVarQueryParams.addAll(apiClient.parameterToPair("vorname", vorname));
        localVarQueryParams.addAll(apiClient.parameterToPair("sichtfreigabe", sichtfreigabe));

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<List<Personendatensatz>> localVarReturnType = new TypeReference<List<Personendatensatz>>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Aktualisiert die Gruppe der angegebenen ID.
     *
     * @param gruppenId (required)
     * @param gruppe (optional)
     * @return Gruppe
     * @throws ApiException if fails to make API call
     */
    public Gruppe updateGruppe(String gruppenId, Gruppe gruppe) throws ApiException {
        return this.updateGruppe(gruppenId, gruppe, Collections.emptyMap());
    }

    /**
     *
     * Aktualisiert die Gruppe der angegebenen ID.
     *
     * @param gruppenId (required)
     * @param gruppe (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return Gruppe
     * @throws ApiException if fails to make API call
     */
    public Gruppe updateGruppe(String gruppenId, Gruppe gruppe, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = gruppe;

        // verify the required parameter 'gruppenId' is set
        if (gruppenId == null) {
            throw new ApiException(400, "Missing the required parameter 'gruppenId' when calling updateGruppe");
        }

        // create path and map variables
        String localVarPath = "/gruppen/{gruppenId}"
                .replaceAll("\\{" + "gruppenId" + "\\}", apiClient.escapeString(gruppenId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Gruppe> localVarReturnType = new TypeReference<Gruppe>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "PUT",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Aktualisiert die Gruppenzugehoerigkeit zur angegebenen ID.
     *
     * @param gruppenzugehoerigkeitId (required)
     * @param gruppenzugehoerigkeit (optional)
     * @return Gruppenzugehoerigkeit
     * @throws ApiException if fails to make API call
     */
    public Gruppenzugehoerigkeit updateGruppenzugehoerigkeit(String gruppenzugehoerigkeitId, Gruppenzugehoerigkeit gruppenzugehoerigkeit) throws ApiException {
        return this.updateGruppenzugehoerigkeit(gruppenzugehoerigkeitId, gruppenzugehoerigkeit, Collections.emptyMap());
    }

    /**
     *
     * Aktualisiert die Gruppenzugehoerigkeit zur angegebenen ID.
     *
     * @param gruppenzugehoerigkeitId (required)
     * @param gruppenzugehoerigkeit (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return Gruppenzugehoerigkeit
     * @throws ApiException if fails to make API call
     */
    public Gruppenzugehoerigkeit updateGruppenzugehoerigkeit(String gruppenzugehoerigkeitId, Gruppenzugehoerigkeit gruppenzugehoerigkeit, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = gruppenzugehoerigkeit;

        // verify the required parameter 'gruppenzugehoerigkeitId' is set
        if (gruppenzugehoerigkeitId == null) {
            throw new ApiException(400, "Missing the required parameter 'gruppenzugehoerigkeitId' when calling updateGruppenzugehoerigkeit");
        }

        // create path and map variables
        String localVarPath = "/gruppenzugehoerigkeiten/{gruppenzugehoerigkeitId}"
                .replaceAll("\\{" + "gruppenzugehoerigkeitId" + "\\}", apiClient.escapeString(gruppenzugehoerigkeitId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Gruppenzugehoerigkeit> localVarReturnType = new TypeReference<Gruppenzugehoerigkeit>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "PUT",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Aktualisiert die Person der angegebenen ID.
     *
     * @param personId (required)
     * @param person (optional)
     * @return Person
     * @throws ApiException if fails to make API call
     */
    public Person updatePerson(String personId, Person person) throws ApiException {
        return this.updatePerson(personId, person, Collections.emptyMap());
    }

    /**
     *
     * Aktualisiert die Person der angegebenen ID.
     *
     * @param personId (required)
     * @param person (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return Person
     * @throws ApiException if fails to make API call
     */
    public Person updatePerson(String personId, Person person, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = person;

        // verify the required parameter 'personId' is set
        if (personId == null) {
            throw new ApiException(400, "Missing the required parameter 'personId' when calling updatePerson");
        }

        // create path and map variables
        String localVarPath = "/personen/{personId}"
                .replaceAll("\\{" + "personId" + "\\}", apiClient.escapeString(personId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Person> localVarReturnType = new TypeReference<Person>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "PUT",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Aktualisiert den Personenkontext zur angegebenen ID.
     *
     * @param personenkontextId (required)
     * @param personenkontext (optional)
     * @return Personenkontext
     * @throws ApiException if fails to make API call
     */
    public Personenkontext updatePersonenkontext(String personenkontextId, Personenkontext personenkontext) throws ApiException {
        return this.updatePersonenkontext(personenkontextId, personenkontext, Collections.emptyMap());
    }

    /**
     *
     * Aktualisiert den Personenkontext zur angegebenen ID.
     *
     * @param personenkontextId (required)
     * @param personenkontext (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return Personenkontext
     * @throws ApiException if fails to make API call
     */
    public Personenkontext updatePersonenkontext(String personenkontextId, Personenkontext personenkontext, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = personenkontext;

        // verify the required parameter 'personenkontextId' is set
        if (personenkontextId == null) {
            throw new ApiException(400, "Missing the required parameter 'personenkontextId' when calling updatePersonenkontext");
        }

        // create path and map variables
        String localVarPath = "/personenkontexte/{personenkontextId}"
                .replaceAll("\\{" + "personenkontextId" + "\\}", apiClient.escapeString(personenkontextId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Personenkontext> localVarReturnType = new TypeReference<Personenkontext>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "PUT",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Endpoint to create and initiate a pipeline. ### Paragraph In a hole in
     * the ground there lived a hobbit. Not a **nasty**, _dirty_,
     * &#x60;wet&#x60; hole, filled with the ends of worms and an oozy smell,
     * nor yet a dry, bare, sandy hole with nothing in it to sit down on or to
     * eat: it was a
     * [hobbit-hole](https://en.wikipedia.org/wiki/Hobbit#Lifestyle
     * \&quot;Hobbit lifestyles\&quot;), and that means comfort. ### Horizontal
     * Rule &#x60;---&#x60; --- ### Number List 1. Install &#x60;node&#x60;. 2.
     * Install &#x60;npm&#x60;. 3. Open your editor 4. Create a JavaScript file
     * ### Blockquotes &gt; This is a sample OpenAPI spec to test the parsing of
     * various markdown styles &gt; (RapiDoc supports common-mark syntax) ###
     * Buleted List - Install &#x60;node&#x60;. - Install &#x60;npm&#x60;. -
     * Open you editor - Create a JavaScript file ### Table | Heading 1 |
     * Left-Justified | Centered | Right-Justified | | --------- |
     * :------------- | :------: | --------------: | | text | text | text | text
     * | | text | text | text | text | | text | text | text | text | ### Code
     * &#x60;&#x60;&#x60; $ curl -X POST -is -u username:password -H
     * \&quot;Content-Type: application/json\&quot; https://example.com -d
     * &#39;{ \&quot;target\&quot;: { \&quot;ref_type\&quot;:
     * \&quot;branch\&quot;, \&quot;type\&quot;:
     * \&quot;pipeline_ref_target\&quot;, \&quot;ref_name\&quot;:
     * \&quot;master\&quot; }&#39; } &#x60;&#x60;&#x60; ### Code (with syntax
     * highlight) &#x60;&#x60;&#x60;bash $ curl -X POST -is -u username:password
     * -H \&quot;Content-Type: application/json\&quot; https://example.com -d
     * &#39;{ \&quot;target\&quot;: { \&quot;ref_type\&quot;:
     * \&quot;branch\&quot;, \&quot;type\&quot;:
     * \&quot;pipeline_ref_target\&quot;, \&quot;ref_name\&quot;:
     * \&quot;master\&quot; }&#39; } &#x60;&#x60;&#x60; ### Use HTML in markdown
     * &lt;br&gt; &lt;div style&#x3D;\&quot;color: white;
     * background-color:SlateBlue; padding: 12px; border-radius:2px\&quot;&gt;
     * Markdown do not support colors or fancy HTML designs. However, if you
     * need you can put some html directly inside the markup with some inline
     * styling. This box I designed using raw HTML inside the markdown
     * &lt;/div&gt; &lt;br&gt; &lt;div style&#x3D;\&quot;color:#bbb;
     * background-color:#444; padding: 12px 0px 12px 12px;border-left: 5px solid
     * #F06560;\&quot;&gt; &lt;b
     * style&#x3D;\&quot;color:#F06560\&quot;&gt;TIP&lt;/b&gt; Here is another
     * one, done using HTML inside markdown with two different colors to make it
     * appear like a TIP &lt;/div&gt; &lt;br&gt; ### Images Inline Images no-gap
     * - ![appspot image filler](http://ipsumimage.appspot.com/100)![appspot
     * image filler](http://ipsumimage.appspot.com/100) Inline Images Single
     * space gap - ![appspot image filler](http://ipsumimage.appspot.com/100)
     * ![appspot image filler](http://ipsumimage.appspot.com/100) Next Line
     * Image ![appspot image filler](http://ipsumimage.appspot.com/140x100.png)
     *
     * @param personenkontextId (required)
     * @param hatAlsBeziehungen Der Defaultwert ist \&quot;ja\&quot;, es werden
     * also ohne Filterangabe alle Beziehungen angegeben, welche ein
     * Personenkontext hat. (optional)
     * @param istVonBeziehungen Der Defaultwert ist \&quot;nein\&quot;, es
     * werden also ohne Filterangabe keine Beziehungen angegeben, welche zu dem
     * gegebenen Personenkontext bestehen. (optional)
     * @return Beziehungendatensatz
     * @throws ApiException if fails to make API call
     */
    public Beziehungendatensatz searchBeziehungen(String personenkontextId, String hatAlsBeziehungen, String istVonBeziehungen) throws ApiException {
        return this.searchBeziehungen(personenkontextId, hatAlsBeziehungen, istVonBeziehungen, Collections.emptyMap());
    }

    /**
     *
     * Endpoint to create and initiate a pipeline. ### Paragraph In a hole in
     * the ground there lived a hobbit. Not a **nasty**, _dirty_,
     * &#x60;wet&#x60; hole, filled with the ends of worms and an oozy smell,
     * nor yet a dry, bare, sandy hole with nothing in it to sit down on or to
     * eat: it was a
     * [hobbit-hole](https://en.wikipedia.org/wiki/Hobbit#Lifestyle
     * \&quot;Hobbit lifestyles\&quot;), and that means comfort. ### Horizontal
     * Rule &#x60;---&#x60; --- ### Number List 1. Install &#x60;node&#x60;. 2.
     * Install &#x60;npm&#x60;. 3. Open your editor 4. Create a JavaScript file
     * ### Blockquotes &gt; This is a sample OpenAPI spec to test the parsing of
     * various markdown styles &gt; (RapiDoc supports common-mark syntax) ###
     * Buleted List - Install &#x60;node&#x60;. - Install &#x60;npm&#x60;. -
     * Open you editor - Create a JavaScript file ### Table | Heading 1 |
     * Left-Justified | Centered | Right-Justified | | --------- |
     * :------------- | :------: | --------------: | | text | text | text | text
     * | | text | text | text | text | | text | text | text | text | ### Code
     * &#x60;&#x60;&#x60; $ curl -X POST -is -u username:password -H
     * \&quot;Content-Type: application/json\&quot; https://example.com -d
     * &#39;{ \&quot;target\&quot;: { \&quot;ref_type\&quot;:
     * \&quot;branch\&quot;, \&quot;type\&quot;:
     * \&quot;pipeline_ref_target\&quot;, \&quot;ref_name\&quot;:
     * \&quot;master\&quot; }&#39; } &#x60;&#x60;&#x60; ### Code (with syntax
     * highlight) &#x60;&#x60;&#x60;bash $ curl -X POST -is -u username:password
     * -H \&quot;Content-Type: application/json\&quot; https://example.com -d
     * &#39;{ \&quot;target\&quot;: { \&quot;ref_type\&quot;:
     * \&quot;branch\&quot;, \&quot;type\&quot;:
     * \&quot;pipeline_ref_target\&quot;, \&quot;ref_name\&quot;:
     * \&quot;master\&quot; }&#39; } &#x60;&#x60;&#x60; ### Use HTML in markdown
     * &lt;br&gt; &lt;div style&#x3D;\&quot;color: white;
     * background-color:SlateBlue; padding: 12px; border-radius:2px\&quot;&gt;
     * Markdown do not support colors or fancy HTML designs. However, if you
     * need you can put some html directly inside the markup with some inline
     * styling. This box I designed using raw HTML inside the markdown
     * &lt;/div&gt; &lt;br&gt; &lt;div style&#x3D;\&quot;color:#bbb;
     * background-color:#444; padding: 12px 0px 12px 12px;border-left: 5px solid
     * #F06560;\&quot;&gt; &lt;b
     * style&#x3D;\&quot;color:#F06560\&quot;&gt;TIP&lt;/b&gt; Here is another
     * one, done using HTML inside markdown with two different colors to make it
     * appear like a TIP &lt;/div&gt; &lt;br&gt; ### Images Inline Images no-gap
     * - ![appspot image filler](http://ipsumimage.appspot.com/100)![appspot
     * image filler](http://ipsumimage.appspot.com/100) Inline Images Single
     * space gap - ![appspot image filler](http://ipsumimage.appspot.com/100)
     * ![appspot image filler](http://ipsumimage.appspot.com/100) Next Line
     * Image ![appspot image filler](http://ipsumimage.appspot.com/140x100.png)
     *
     * @param personenkontextId (required)
     * @param hatAlsBeziehungen Der Defaultwert ist \&quot;ja\&quot;, es werden
     * also ohne Filterangabe alle Beziehungen angegeben, welche ein
     * Personenkontext hat. (optional)
     * @param istVonBeziehungen Der Defaultwert ist \&quot;nein\&quot;, es
     * werden also ohne Filterangabe keine Beziehungen angegeben, welche zu dem
     * gegebenen Personenkontext bestehen. (optional)
     * @param additionalHeaders additionalHeaders for this call
     * @return Beziehungendatensatz
     * @throws ApiException if fails to make API call
     */
    public Beziehungendatensatz searchBeziehungen(String personenkontextId, String hatAlsBeziehungen, String istVonBeziehungen, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // verify the required parameter 'personenkontextId' is set
        if (personenkontextId == null) {
            throw new ApiException(400, "Missing the required parameter 'personenkontextId' when calling searchBeziehungen");
        }

        // create path and map variables
        String localVarPath = "/personenkontexte/{personenkontextId}/beziehungen"
                .replaceAll("\\{" + "personenkontextId" + "\\}", apiClient.escapeString(personenkontextId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarQueryParams.addAll(apiClient.parameterToPair("hat_als_beziehungen", hatAlsBeziehungen));
        localVarQueryParams.addAll(apiClient.parameterToPair("ist_von_beziehungen", istVonBeziehungen));

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<Beziehungendatensatz> localVarReturnType = new TypeReference<Beziehungendatensatz>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }

    /**
     *
     * Liefert die Beziehung zur angeforderten ID.
     *
     * @param beziehungId (required)
     * @return BeziehungReadResponse
     * @throws ApiException if fails to make API call
     */
    public BeziehungReadResponse readBeziehung(String beziehungId) throws ApiException {
        return this.readBeziehung(beziehungId, Collections.emptyMap());
    }

    /**
     *
     * Liefert die Beziehung zur angeforderten ID.
     *
     * @param beziehungId (required)
     * @param additionalHeaders additionalHeaders for this call
     * @return BeziehungReadResponse
     * @throws ApiException if fails to make API call
     */
    public BeziehungReadResponse readBeziehung(String beziehungId, Map<String, String> additionalHeaders) throws ApiException {
        Object localVarPostBody = null;

        // verify the required parameter 'beziehungId' is set
        if (beziehungId == null) {
            throw new ApiException(400, "Missing the required parameter 'beziehungId' when calling readBeziehung");
        }

        // create path and map variables
        String localVarPath = "/beziehungen/{beziehungId}"
                .replaceAll("\\{" + "beziehungId" + "\\}", apiClient.escapeString(beziehungId.toString()));

        StringJoiner localVarQueryStringJoiner = new StringJoiner("&");
        String localVarQueryParameterBaseName;
        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        Map<String, String> localVarHeaderParams = new HashMap<String, String>();
        Map<String, String> localVarCookieParams = new HashMap<String, String>();
        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        localVarHeaderParams.putAll(additionalHeaders);

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

        final String[] localVarContentTypes = {};
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[]{};

        TypeReference<BeziehungReadResponse> localVarReturnType = new TypeReference<BeziehungReadResponse>() {
        };
        return apiClient.invokeAPI(
                localVarPath,
                "GET",
                localVarQueryParams,
                localVarCollectionQueryParams,
                localVarQueryStringJoiner.toString(),
                localVarPostBody,
                localVarHeaderParams,
                localVarCookieParams,
                localVarFormParams,
                localVarAccept,
                localVarContentType,
                localVarAuthNames,
                localVarReturnType
        );
    }
}
