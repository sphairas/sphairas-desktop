/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.schulconnex.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.schulconnex.Pair;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import org.apache.hc.client5.http.entity.UrlEncodedFormEntity;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.protocol.HttpClientContext;
import org.apache.hc.core5.http.ClassicHttpRequest;
import org.apache.hc.core5.http.ClassicHttpResponse;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.HttpException;
import org.apache.hc.core5.http.HttpStatus;
import org.apache.hc.core5.http.NameValuePair;
import org.apache.hc.core5.http.io.HttpClientResponseHandler;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.http.io.support.ClassicRequestBuilder;
import org.apache.hc.core5.http.message.BasicNameValuePair;

/**
 *
 * @author boris.heithecker@gmx.net
 */
public class HttpTokenAuth implements Authentication, HttpClientResponseHandler<TokenResponse> {

    private final CloseableHttpClient httpClient = HttpClients.createDefault();
    private String username;
    private String password;
    private String tokenEndpoint;
    private final ObjectMapper objectMapper;
    private TokenResponse token;

    public HttpTokenAuth() {
        objectMapper = new ObjectMapper();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTokenEndpoint() {
        return tokenEndpoint;
    }

    public void setTokenEndpoint(String tokenEndpoint) {
        this.tokenEndpoint = tokenEndpoint;
    }

    @Override
    public void applyToParams(List<Pair> queryParams, Map<String, String> headerParams, Map<String, String> cookieParams) throws IOException {
        if (token == null || !token.isValid()) {
            try {
                token = fetchToken();
            } catch (IOException ex) {
                token = null;
                throw ex;
            }
        }
        headerParams.put("Authorization", token.getTokenType() + " " + token.getAccessToken());
    }

    public String getToken() {
        if (token != null && token.isValid()) {
            return token.getAccessToken();
        }
        try {
            token = fetchToken();
            return token.getAccessToken();
        } catch (IOException ex) {
            token = null;
            return null;
        }
    }

    private TokenResponse fetchToken() throws IOException {
        HttpClientContext context = HttpClientContext.create();

        ClassicRequestBuilder builder = ClassicRequestBuilder.create("POST");
        builder.setUri(tokenEndpoint);

        final String auth = username + ":" + password;
        builder.addHeader("Authorization", "Basic " + Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8)));

        List<NameValuePair> formValues = new ArrayList<>();
        formValues.add(new BasicNameValuePair("grant_type", "client_credentials"));
        builder.setEntity(new UrlEncodedFormEntity(formValues, ContentType.APPLICATION_FORM_URLENCODED.getCharset()));

        final ClassicHttpRequest request = builder.build();
        return httpClient.execute(request, context, this);
    }

    @Override
    public TokenResponse handleResponse(ClassicHttpResponse response) throws HttpException, IOException {
        int statusCode = response.getCode();
        if (statusCode == HttpStatus.SC_NO_CONTENT) {
            return null;
        }
        if (statusCode >= 200 && statusCode < 300) {
            HttpEntity entity = response.getEntity();
            String content = EntityUtils.toString(entity);
            return objectMapper.readValue(content, TokenResponse.class);
        } else {
            String message = EntityUtils.toString(response.getEntity());
            throw new IOException(message);
        }
    }

}
