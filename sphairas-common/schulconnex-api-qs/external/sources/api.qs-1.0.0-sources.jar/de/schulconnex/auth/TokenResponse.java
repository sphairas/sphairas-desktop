/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.schulconnex.auth;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;

/**
 *
 * @author boris.heithecker@gmx.net
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class TokenResponse {

    public static final String JSON_PROPERTY_ACCESS_TOKEN = "access_token";
    private String accessToken;
    public static final String JSON_PROPERTY_EXPIRES_IN = "expires_in";
//    "expires_in": 3600,
    private int expiresIn;
//    "refresh_expires_in": 0,
    public static final String JSON_PROPERTY_TOKEN_TYPE = "token_type";
//    "token_type": "Bearer",
    private String tokenType;
//    "not-before-policy": 0,
//    "scope": ""
    private LocalDateTime expires;

    @JsonProperty(JSON_PROPERTY_ACCESS_TOKEN)
    public String getAccessToken() {
        return accessToken;
    }

    @JsonProperty(JSON_PROPERTY_ACCESS_TOKEN)
    public void setAccessToken(String access_token) {
        this.accessToken = access_token;
    }

    @JsonProperty(JSON_PROPERTY_EXPIRES_IN)
    public int getExpiresIn() {
        return expiresIn;
    }

    @JsonProperty(JSON_PROPERTY_EXPIRES_IN)
    public void setExpiresIn(int expiresIn) {
        this.expiresIn = expiresIn;
        expires = LocalDateTime.now().plusSeconds(expiresIn);
    }

    public boolean isValid() {
        return expires.compareTo(LocalDateTime.now()) > 0;
    }

    @JsonProperty(JSON_PROPERTY_TOKEN_TYPE)
    public String getTokenType() {
        return tokenType;
    }

    @JsonProperty(JSON_PROPERTY_TOKEN_TYPE)
    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

}
