package de.schulconnex.qs.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.StringJoiner;
import java.util.stream.Collectors;

/**
 * Gruppenzugehoerigkeit
 */
@JsonPropertyOrder({
    Gruppenzugehoerigkeit.JSON_PROPERTY_ID,
    Gruppenzugehoerigkeit.JSON_PROPERTY_REFERRER,
    Gruppenzugehoerigkeit.JSON_PROPERTY_MANDANT,
    Gruppenzugehoerigkeit.JSON_PROPERTY_KTID,
    Gruppenzugehoerigkeit.JSON_PROPERTY_ROLLEN,
    Gruppenzugehoerigkeit.JSON_PROPERTY_VON,
    Gruppenzugehoerigkeit.JSON_PROPERTY_BIS,
    Gruppenzugehoerigkeit.JSON_PROPERTY_REVISION
})
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2024-04-05T18:25:56.866712+02:00[Europe/Berlin]", comments = "Generator version: 7.4.0")
public class Gruppenzugehoerigkeit extends SchulconnexEntitaet {
    
    public static final String JSON_PROPERTY_KTID = "ktid";
    private String ktid;

    public static final String JSON_PROPERTY_ROLLEN = "rollen";
    private final List<String> rollen = new ArrayList<>();

    public static final String JSON_PROPERTY_VON = "von";
    private LocalDate von;

    public static final String JSON_PROPERTY_BIS = "bis";
    private LocalDate bis;

    public Gruppenzugehoerigkeit() {
    }

    public Gruppenzugehoerigkeit id(String id) {
        this.id = id;
        return this;
    }

    public Gruppenzugehoerigkeit referrer(String referrer) {
        this.referrer = referrer;
        return this;
    }

    public Gruppenzugehoerigkeit mandant(String mandant) {
        this.mandant = mandant;
        return this;
    }

    public Gruppenzugehoerigkeit ktid(String ktid) {
        this.ktid = ktid;
        return this;
    }

    /**
     * String (UTF-8) - ID des Personenkontexts, welchem die Gruppe zugeordnet
     * ist.
     *
     * @return ktid
     *
     */
    @javax.annotation.Nonnull
    @JsonProperty(JSON_PROPERTY_KTID)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public String getKtid() {
        return ktid;
    }

    @JsonProperty(JSON_PROPERTY_KTID)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public void setKtid(String ktid) {
        this.ktid = ktid;
    }

    public Gruppenzugehoerigkeit rollen(List<String> rollen) {
        this.rollen.clear();
        this.rollen.addAll(rollen);
        return this;
    }

    public Gruppenzugehoerigkeit addRollenItem(String rollenItem) {
        this.rollen.add(rollenItem);
        return this;
    }

    /**
     * Get rollen
     *
     * @return rollen
     *
     */
    @javax.annotation.Nonnull
    @JsonProperty(JSON_PROPERTY_ROLLEN)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public List<String> getRollen() {
        return rollen;
    }

    @JsonProperty(JSON_PROPERTY_ROLLEN)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public void setRollen(List<String> rollen) {
        this.rollen.clear();
        this.rollen.addAll(rollen);
    }

    public Gruppenzugehoerigkeit von(LocalDate von) {
        this.von = von;
        return this;
    }

    /**
     * Datum - Beginn der Gruppenzugehörigkeit. Dieser Zeitpunkt kann auch in
     * der Zukunft liegen.
     *
     * @return von
     *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_VON)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public LocalDate getVon() {
        return von;
    }

    @JsonProperty(JSON_PROPERTY_VON)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setVon(LocalDate von) {
        this.von = von;
    }

    public Gruppenzugehoerigkeit bis(LocalDate bis) {
        this.bis = bis;
        return this;
    }

    /**
     * Datum - Ende der Gruppenzugehörigkeit
     *
     * @return bis
     *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_BIS)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public LocalDate getBis() {
        return bis;
    }

    @JsonProperty(JSON_PROPERTY_BIS)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setBis(LocalDate bis) {
        this.bis = bis;
    }

    public Gruppenzugehoerigkeit revision(String revision) {
        this.revision = revision;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Gruppenzugehoerigkeit gruppenzugehoerigkeit = (Gruppenzugehoerigkeit) o;
        return Objects.equals(this.id, gruppenzugehoerigkeit.id)
                && Objects.equals(this.referrer, gruppenzugehoerigkeit.referrer)
                && Objects.equals(this.mandant, gruppenzugehoerigkeit.mandant)
                && Objects.equals(this.ktid, gruppenzugehoerigkeit.ktid)
                && Objects.equals(this.rollen, gruppenzugehoerigkeit.rollen)
                && Objects.equals(this.von, gruppenzugehoerigkeit.von)
                && Objects.equals(this.bis, gruppenzugehoerigkeit.bis)
                && Objects.equals(this.revision, gruppenzugehoerigkeit.revision);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id,
                referrer,
                mandant,
                ktid,
                rollen.stream().map(String::toUpperCase).collect(Collectors.toList()),
                von,
                bis,
                revision);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Gruppenzugehoerigkeit {\n");
        sb.append("    id: ").append(toIndentedString(id)).append("\n");
        sb.append("    referrer: ").append(toIndentedString(referrer)).append("\n");
        sb.append("    mandant: ").append(toIndentedString(mandant)).append("\n");
        sb.append("    ktid: ").append(toIndentedString(ktid)).append("\n");
        sb.append("    rollen: ").append(toIndentedString(rollen)).append("\n");
        sb.append("    von: ").append(toIndentedString(von)).append("\n");
        sb.append("    bis: ").append(toIndentedString(bis)).append("\n");
        sb.append("    revision: ").append(toIndentedString(revision)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

    /**
     * Convert the instance into URL query string.
     *
     * @return URL query string
     */
    public String toUrlQueryString() {
        return toUrlQueryString(null);
    }

    /**
     * Convert the instance into URL query string.
     *
     * @param prefix prefix of the query string
     * @return URL query string
     */
    public String toUrlQueryString(String prefix) {
        String suffix = "";
        String containerSuffix = "";
        String containerPrefix = "";
        if (prefix == null) {
            // style=form, explode=true, e.g. /pet?name=cat&type=manx
            prefix = "";
        } else {
            // deepObject style e.g. /pet?id[name]=cat&id[type]=manx
            prefix = prefix + "[";
            suffix = "]";
            containerSuffix = "]";
            containerPrefix = "[";
        }

        StringJoiner joiner = new StringJoiner("&");

        // add `id` to the URL query string
        if (getId() != null) {
            try {
                joiner.add(String.format("%sid%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getId()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `referrer` to the URL query string
        if (getReferrer() != null) {
            try {
                joiner.add(String.format("%sreferrer%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getReferrer()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `mandant` to the URL query string
        if (getMandant() != null) {
            try {
                joiner.add(String.format("%smandant%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getMandant()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `ktid` to the URL query string
        if (getKtid() != null) {
            try {
                joiner.add(String.format("%sktid%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getKtid()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `rollen` to the URL query string
        if (getRollen() != null) {
            for (int i = 0; i < getRollen().size(); i++) {
                try {
                    joiner.add(String.format("%srollen%s%s=%s", prefix, suffix,
                            "".equals(suffix) ? "" : String.format("%s%d%s", containerPrefix, i, containerSuffix),
                            URLEncoder.encode(String.valueOf(getRollen().get(i)), "UTF-8").replaceAll("\\+", "%20")));
                } catch (UnsupportedEncodingException e) {
                    // Should never happen, UTF-8 is always supported
                    throw new RuntimeException(e);
                }
            }
        }

        // add `von` to the URL query string
        if (getVon() != null) {
            try {
                joiner.add(String.format("%svon%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getVon()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `bis` to the URL query string
        if (getBis() != null) {
            try {
                joiner.add(String.format("%sbis%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getBis()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `revision` to the URL query string
        if (getRevision() != null) {
            try {
                joiner.add(String.format("%srevision%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getRevision()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        return joiner.toString();
    }

}
