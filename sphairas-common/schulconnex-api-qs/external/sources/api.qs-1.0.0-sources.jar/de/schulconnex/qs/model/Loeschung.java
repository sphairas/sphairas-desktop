package de.schulconnex.qs.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import de.schulconnex.JSON;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.time.ZonedDateTime;
import java.util.StringJoiner;

/**
 * Loeschung
 */
@JsonPropertyOrder({
    Loeschung.JSON_PROPERTY_ZEITPUNKT
})
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2024-04-05T18:25:56.866712+02:00[Europe/Berlin]", comments = "Generator version: 7.4.0")
public class Loeschung {

    public static final String JSON_PROPERTY_ZEITPUNKT = "zeitpunkt";
    private ZonedDateTime zeitpunkt;

    public Loeschung() {
    }

    public Loeschung zeitpunkt(ZonedDateTime zeitpunkt) {
        this.zeitpunkt = zeitpunkt;
        return this;
    }

    /**
     * String (datetime) - Datum und Uhrzeit der Löschung desPersonenkontexts
     * Das Format des Löschzeitpunktes ist yyyy-MM-dd&#39;T&#39;hh:mm&#39;Z&#39;
     * als UTC-Zeitpunkt. Solange ein Personenkontext nicht gelöscht wurde, kann
     * das Attribut loeschzeitpunkt geändert oder gelöscht werden. Ist das
     * Attribut loeschung vorhanden, so muss der Zeitpunkt gesetzt sein.
     *
     * @return zeitpunkt
     *
     */
    @javax.annotation.Nonnull
    @JsonProperty(JSON_PROPERTY_ZEITPUNKT)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    @JsonSerialize(using = JSON.LoeschzeitSerializer.class)
    public ZonedDateTime getZeitpunkt() {
        return zeitpunkt;
    }

    @JsonProperty(JSON_PROPERTY_ZEITPUNKT)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    @JsonDeserialize(using = JSON.LoeschzeitDeserializer.class)
    public void setZeitpunkt(ZonedDateTime zeitpunkt) {
        this.zeitpunkt = zeitpunkt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Loeschung loeschung = (Loeschung) o;
        return Objects.equals(this.zeitpunkt, loeschung.zeitpunkt);
    }

    @Override
    public int hashCode() {
        return Objects.hash(zeitpunkt);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Loeschung {\n");
        sb.append("    zeitpunkt: ").append(toIndentedString(zeitpunkt)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

    /**
     * Convert the instance into URL query string.
     *
     * @return URL query string
     */
    public String toUrlQueryString() {
        return toUrlQueryString(null);
    }

    /**
     * Convert the instance into URL query string.
     *
     * @param prefix prefix of the query string
     * @return URL query string
     */
    public String toUrlQueryString(String prefix) {
        String suffix = "";
        String containerSuffix = "";
        String containerPrefix = "";
        if (prefix == null) {
            // style=form, explode=true, e.g. /pet?name=cat&type=manx
            prefix = "";
        } else {
            // deepObject style e.g. /pet?id[name]=cat&id[type]=manx
            prefix = prefix + "[";
            suffix = "]";
            containerSuffix = "]";
            containerPrefix = "[";
        }

        StringJoiner joiner = new StringJoiner("&");

        // add `zeitpunkt` to the URL query string
        if (getZeitpunkt() != null) {
            try {
                joiner.add(String.format("%szeitpunkt%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getZeitpunkt()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        return joiner.toString();
    }

}
