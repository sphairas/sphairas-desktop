package de.schulconnex.qs.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.StringJoiner;
import org.apache.commons.lang.StringUtils;

/**
 * Eine Organisation stellt eine Schule oder sonstige relevante Organisation im
 * Kontext EINES SchulConneX-Services dar.
 */
@JsonPropertyOrder({
    Organisation.JSON_PROPERTY_ID,
    Organisation.JSON_PROPERTY_KENNUNG,
    Organisation.JSON_PROPERTY_NAME,
    Organisation.JSON_PROPERTY_NAMENSERGAENZUNG,
    Organisation.JSON_PROPERTY_KUERZEL,
    Organisation.JSON_PROPERTY_ANSCHRIFT,
    Organisation.JSON_PROPERTY_TYP,
    Organisation.JSON_PROPERTY_TRAEGERSCHAFT
})
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2024-04-05T18:25:56.866712+02:00[Europe/Berlin]", comments = "Generator version: 7.4.0")
public class Organisation extends SchulconnexEntitaet {

    public static final String JSON_PROPERTY_KENNUNG = "kennung";
    private String kennung;

    public static final String JSON_PROPERTY_NAME = "name";
    private String name;

    public static final String JSON_PROPERTY_NAMENSERGAENZUNG = "namensergaenzung";
    private String namensergaenzung;

    public static final String JSON_PROPERTY_KUERZEL = "kuerzel";
    private String kuerzel;

    public static final String JSON_PROPERTY_ANSCHRIFT = "anschrift";
    private Anschrift anschrift;

    public static final String JSON_PROPERTY_TYP = "typ";
    private String typ;

    public static final String JSON_PROPERTY_TRAEGERSCHAFT = "traegerschaft";
    private String traegerschaft;

    public Organisation() {
    }

    public Organisation id(String id) {
        this.id = id;
        return this;
    }

    public Organisation kennung(String kennung) {
        this.kennung = kennung;
        return this;
    }

    /**
     * String (UTF-8) - Die optionale Kennung (Identifikations-ID) einer
     * \&quot;Organisation\&quot; muss innerhalb eines Organisationstyps
     * eindeutig sein.
     *
     * @return kennung
  *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_KENNUNG)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public String getKennung() {
        return kennung;
    }

    @JsonProperty(JSON_PROPERTY_KENNUNG)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setKennung(String kennung) {
        this.kennung = kennung;
    }

    public Organisation name(String name) {
        this.name = name;
        return this;
    }

    /**
     * String (DIN 91379.B) - Offizieller Name einer Organisation.
     *
     * @return name
  *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_NAME)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public String getName() {
        return name;
    }

    @JsonProperty(JSON_PROPERTY_NAME)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setName(String name) {
        this.name = name;
    }

    public Organisation namensergaenzung(String namensergaenzung) {
        this.namensergaenzung = namensergaenzung;
        return this;
    }

    /**
     * String (DIN 91379.B) - Ergänzender Name einer Organisation.
     *
     * @return namensergaenzung
  *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_NAMENSERGAENZUNG)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public String getNamensergaenzung() {
        return namensergaenzung;
    }

    @JsonProperty(JSON_PROPERTY_NAMENSERGAENZUNG)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setNamensergaenzung(String namensergaenzung) {
        this.namensergaenzung = namensergaenzung;
    }

    public Organisation kuerzel(String kuerzel) {
        this.kuerzel = kuerzel;
        return this;
    }

    /**
     * String (64) (DIN 91379.B) - Kurzname einer Organisation.
     *
     * @return kuerzel
  *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_KUERZEL)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public String getKuerzel() {
        return kuerzel;
    }

    @JsonProperty(JSON_PROPERTY_KUERZEL)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setKuerzel(String kuerzel) {
        this.kuerzel = kuerzel;
    }

    public Organisation anschrift(Anschrift anschrift) {
        this.anschrift = anschrift;
        return this;
    }

    /**
     * Get anschrift
     *
     * @return anschrift
  *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_ANSCHRIFT)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public Anschrift getAnschrift() {
        return anschrift;
    }

    @JsonProperty(JSON_PROPERTY_ANSCHRIFT)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setAnschrift(Anschrift anschrift) {
        this.anschrift = anschrift;
    }

    public Organisation typ(String typ) {
        this.typ = typ;
        return this;
    }

    /**
     * String (Code) - Typ der Organisation. Referenz auf einen Code der
     * Codeliste 11.5 Organisationstyp.
     *
     * @return typ
  *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_TYP)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public String getTyp() {
        return typ;
    }

    @JsonProperty(JSON_PROPERTY_TYP)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setTyp(String typ) {
        this.typ = typ;
    }

    public Organisation traegerschaft(String traegerschaft) {

        this.traegerschaft = traegerschaft;
        return this;
    }

    /**
     * String (Code) - Art der Trägerschaft der Organisation. Referenz auf einen
     * Code der Codeliste 11.8 Trägerschaft.
     *
     * @return traegerschaft
  *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_TRAEGERSCHAFT)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)

    public String getTraegerschaft() {
        return traegerschaft;
    }

    @JsonProperty(JSON_PROPERTY_TRAEGERSCHAFT)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setTraegerschaft(String traegerschaft) {
        this.traegerschaft = traegerschaft;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Organisation organisation = (Organisation) o;
        return Objects.equals(this.id, organisation.id)
                && Objects.equals(this.kennung, organisation.kennung)
                && Objects.equals(this.name, organisation.name)
                && Objects.equals(this.namensergaenzung, organisation.namensergaenzung)
                && Objects.equals(this.kuerzel, organisation.kuerzel)
                && Objects.equals(this.anschrift, organisation.anschrift)
                && Objects.equals(this.typ, organisation.typ)
                && Objects.equals(this.traegerschaft, organisation.traegerschaft);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id,
                kennung, 
                name, 
                namensergaenzung, 
                kuerzel, 
                anschrift, 
                StringUtils.upperCase(typ), 
                StringUtils.upperCase(traegerschaft));
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Organisation {\n");
        sb.append("    id: ").append(toIndentedString(id)).append("\n");
        sb.append("    kennung: ").append(toIndentedString(kennung)).append("\n");
        sb.append("    name: ").append(toIndentedString(name)).append("\n");
        sb.append("    namensergaenzung: ").append(toIndentedString(namensergaenzung)).append("\n");
        sb.append("    kuerzel: ").append(toIndentedString(kuerzel)).append("\n");
        sb.append("    anschrift: ").append(toIndentedString(anschrift)).append("\n");
        sb.append("    typ: ").append(toIndentedString(typ)).append("\n");
        sb.append("    traegerschaft: ").append(toIndentedString(traegerschaft)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

    /**
     * Convert the instance into URL query string.
     *
     * @return URL query string
     */
    public String toUrlQueryString() {
        return toUrlQueryString(null);
    }

    /**
     * Convert the instance into URL query string.
     *
     * @param prefix prefix of the query string
     * @return URL query string
     */
    public String toUrlQueryString(String prefix) {
        String suffix = "";
        String containerSuffix = "";
        String containerPrefix = "";
        if (prefix == null) {
            // style=form, explode=true, e.g. /pet?name=cat&type=manx
            prefix = "";
        } else {
            // deepObject style e.g. /pet?id[name]=cat&id[type]=manx
            prefix = prefix + "[";
            suffix = "]";
            containerSuffix = "]";
            containerPrefix = "[";
        }

        StringJoiner joiner = new StringJoiner("&");

        // add `id` to the URL query string
        if (getId() != null) {
            try {
                joiner.add(String.format("%sid%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getId()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `kennung` to the URL query string
        if (getKennung() != null) {
            try {
                joiner.add(String.format("%skennung%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getKennung()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `name` to the URL query string
        if (getName() != null) {
            try {
                joiner.add(String.format("%sname%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getName()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `namensergaenzung` to the URL query string
        if (getNamensergaenzung() != null) {
            try {
                joiner.add(String.format("%snamensergaenzung%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getNamensergaenzung()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `kuerzel` to the URL query string
        if (getKuerzel() != null) {
            try {
                joiner.add(String.format("%skuerzel%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getKuerzel()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `anschrift` to the URL query string
        if (getAnschrift() != null) {
            joiner.add(getAnschrift().toUrlQueryString(prefix + "anschrift" + suffix));
        }

        // add `typ` to the URL query string
        if (getTyp() != null) {
            try {
                joiner.add(String.format("%styp%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getTyp()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `traegerschaft` to the URL query string
        if (getTraegerschaft() != null) {
            try {
                joiner.add(String.format("%straegerschaft%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getTraegerschaft()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        return joiner.toString();
    }

}
