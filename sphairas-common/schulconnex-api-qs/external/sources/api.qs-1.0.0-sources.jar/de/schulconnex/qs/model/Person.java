package de.schulconnex.qs.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.StringJoiner;
import org.apache.commons.lang.StringUtils;

/**
 * Datenmodell einer Person
 */
@JsonPropertyOrder({
    Person.JSON_PROPERTY_ID,
    Person.JSON_PROPERTY_REFERRER,
    Person.JSON_PROPERTY_MANDANT,
    Person.JSON_PROPERTY_STAMMORGANISATION,
    Person.JSON_PROPERTY_NAME,
    Person.JSON_PROPERTY_GEBURT,
    Person.JSON_PROPERTY_GESCHLECHT,
    Person.JSON_PROPERTY_LOKALISIERUNG,
    Person.JSON_PROPERTY_VERTRAUENSSTUFE,
    Person.JSON_PROPERTY_AUSKUNFTSSPERRE,
    Person.JSON_PROPERTY_REVISION
})
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2024-04-05T18:25:56.866712+02:00[Europe/Berlin]", comments = "Generator version: 7.4.0")
public class Person extends SchulconnexEntitaet {

    public static final String JSON_PROPERTY_STAMMORGANISATION = "stammorganisation";
    private String stammorganisation;

    public static final String JSON_PROPERTY_NAME = "name";
    private Name name;

    public static final String JSON_PROPERTY_GEBURT = "geburt";
    private Geburt geburt;

    public static final String JSON_PROPERTY_GESCHLECHT = "geschlecht";
    private String geschlecht;

    public static final String JSON_PROPERTY_LOKALISIERUNG = "lokalisierung";
    private String lokalisierung;

    public static final String JSON_PROPERTY_VERTRAUENSSTUFE = "vertrauensstufe";
    private String vertrauensstufe;

    public static final String JSON_PROPERTY_AUSKUNFTSSPERRE = "auskunftssperre";
    private String auskunftssperre;

    public Person() {
    }

    public Person id(String id) {
        this.id = id;
        return this;
    }

    public Person referrer(String referrer) {
        this.referrer = referrer;
        return this;
    }

    public Person mandant(String mandant) {
        this.mandant = mandant;
        return this;
    }

    public Person stammorganisation(String stammorganisation) {
        this.stammorganisation = stammorganisation;
        return this;
    }

    /**
     * String (UTF-8) - Personen können einer Organisation angehören, jedoch
     * zeitweise an einer anderen Organisation tätig sein.
     *
     * @return stammorganisation
     *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_STAMMORGANISATION)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public String getStammorganisation() {
        return stammorganisation;
    }

    @JsonProperty(JSON_PROPERTY_STAMMORGANISATION)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setStammorganisation(String stammorganisation) {
        this.stammorganisation = stammorganisation;
    }

    public Person name(Name name) {
        this.name = name;
        return this;
    }

    /**
     * Get name
     *
     * @return name
     *
     */
    @javax.annotation.Nonnull
    @JsonProperty(JSON_PROPERTY_NAME)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public Name getName() {
        return name;
    }

    @JsonProperty(JSON_PROPERTY_NAME)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public void setName(Name name) {
        this.name = name;
    }

    public Person geburt(Geburt geburt) {
        this.geburt = geburt;
        return this;
    }

    /**
     * Get geburt
     *
     * @return geburt
     *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_GEBURT)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public Geburt getGeburt() {
        return geburt;
    }

    @JsonProperty(JSON_PROPERTY_GEBURT)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setGeburt(Geburt geburt) {
        this.geburt = geburt;
    }

    public Person geschlecht(String geschlecht) {
        this.geschlecht = geschlecht;
        return this;
    }

    /**
     * String (Code) - Referenz auf einen Code der Codeliste 11.2 Geschlecht.
     *
     * @return geschlecht
     *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_GESCHLECHT)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public String getGeschlecht() {
        return geschlecht;
    }

    @JsonProperty(JSON_PROPERTY_GESCHLECHT)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setGeschlecht(String geschlecht) {
        this.geschlecht = geschlecht;
    }

    public Person lokalisierung(String lokalisierung) {
        this.lokalisierung = lokalisierung;
        return this;
    }

    /**
     * String (Code) - bevorzugte Lokalisierungseinstellung einer Person für
     * Anwendungen gemäß RFC5646. Wenn nicht angegeben wird „de“ angenommen.
     * Referenz auf einen Code der Codeliste 11.9 Lokalisierung.
     *
     * @return lokalisierung
     *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_LOKALISIERUNG)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public String getLokalisierung() {
        return lokalisierung;
    }

    @JsonProperty(JSON_PROPERTY_LOKALISIERUNG)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setLokalisierung(String lokalisierung) {
        this.lokalisierung = lokalisierung;
    }

    public Person vertrauensstufe(String vertrauensstufe) {
        this.vertrauensstufe = vertrauensstufe;
        return this;
    }

    /**
     * String (Code) - gibt an, wie stark die Personendaten vom erfassenden
     * Mandanten verifiziert wurden. Referenz auf einen Code der Codeliste 11.4
     * Vertrauensstufe.
     *
     * @return vertrauensstufe
     *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_VERTRAUENSSTUFE)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public String getVertrauensstufe() {
        return vertrauensstufe;
    }

    @JsonProperty(JSON_PROPERTY_VERTRAUENSSTUFE)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setVertrauensstufe(String vertrauensstufe) {
        this.vertrauensstufe = vertrauensstufe;
    }

    public Person auskunftssperre(String auskunftssperre) {
        this.auskunftssperre = auskunftssperre;
        return this;
    }

    /**
     * String (Code) - Auskunftssperre über eine Person. Dienste erhalten nur
     * einen uneingeschränkten Datensatz, wenn der Wert “NEIN” ist. Sofern nicht
     * explizit “JA” eingeben wurde, ist der Default “NEIN”. Referenz auf einen
     * Code der Codeliste 11.7 Boolean
     *
     * @return auskunftssperre
     *
     */
    @javax.annotation.Nonnull
    @JsonProperty(JSON_PROPERTY_AUSKUNFTSSPERRE)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public String getAuskunftssperre() {
        return auskunftssperre;
    }

    @JsonProperty(JSON_PROPERTY_AUSKUNFTSSPERRE)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public void setAuskunftssperre(String auskunftssperre) {
        this.auskunftssperre = auskunftssperre;
    }

    public Person revision(String revision) {
        this.revision = revision;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Person person = (Person) o;
        return Objects.equals(this.id, person.id)
                && Objects.equals(this.referrer, person.referrer)
                && Objects.equals(this.mandant, person.mandant)
                && Objects.equals(this.stammorganisation, person.stammorganisation)
                && Objects.equals(this.name, person.name)
                && Objects.equals(this.geburt, person.geburt)
                && Objects.equals(this.geschlecht, person.geschlecht)
                && Objects.equals(this.lokalisierung, person.lokalisierung)
                && Objects.equals(this.vertrauensstufe, person.vertrauensstufe)
                && Objects.equals(this.auskunftssperre, person.auskunftssperre)
                && Objects.equals(this.revision, person.revision);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, 
                referrer, 
                mandant, 
                stammorganisation, 
                name, 
                geburt, 
                StringUtils.upperCase(geschlecht),
                lokalisierung, 
                vertrauensstufe, 
                auskunftssperre, 
                revision);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Person {\n");
        sb.append("    id: ").append(toIndentedString(id)).append("\n");
        sb.append("    referrer: ").append(toIndentedString(referrer)).append("\n");
        sb.append("    mandant: ").append(toIndentedString(mandant)).append("\n");
        sb.append("    stammorganisation: ").append(toIndentedString(stammorganisation)).append("\n");
        sb.append("    name: ").append(toIndentedString(name)).append("\n");
        sb.append("    geburt: ").append(toIndentedString(geburt)).append("\n");
        sb.append("    geschlecht: ").append(toIndentedString(geschlecht)).append("\n");
        sb.append("    lokalisierung: ").append(toIndentedString(lokalisierung)).append("\n");
        sb.append("    vertrauensstufe: ").append(toIndentedString(vertrauensstufe)).append("\n");
        sb.append("    auskunftssperre: ").append(toIndentedString(auskunftssperre)).append("\n");
        sb.append("    revision: ").append(toIndentedString(revision)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

    /**
     * Convert the instance into URL query string.
     *
     * @return URL query string
     */
    public String toUrlQueryString() {
        return toUrlQueryString(null);
    }

    /**
     * Convert the instance into URL query string.
     *
     * @param prefix prefix of the query string
     * @return URL query string
     */
    public String toUrlQueryString(String prefix) {
        String suffix = "";
        String containerSuffix = "";
        String containerPrefix = "";
        if (prefix == null) {
            // style=form, explode=true, e.g. /pet?name=cat&type=manx
            prefix = "";
        } else {
            // deepObject style e.g. /pet?id[name]=cat&id[type]=manx
            prefix = prefix + "[";
            suffix = "]";
            containerSuffix = "]";
            containerPrefix = "[";
        }

        StringJoiner joiner = new StringJoiner("&");

        // add `id` to the URL query string
        if (getId() != null) {
            try {
                joiner.add(String.format("%sid%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getId()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `referrer` to the URL query string
        if (getReferrer() != null) {
            try {
                joiner.add(String.format("%sreferrer%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getReferrer()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `mandant` to the URL query string
        if (getMandant() != null) {
            try {
                joiner.add(String.format("%smandant%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getMandant()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `stammorganisation` to the URL query string
        if (getStammorganisation() != null) {
            try {
                joiner.add(String.format("%sstammorganisation%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getStammorganisation()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `name` to the URL query string
        if (getName() != null) {
            joiner.add(getName().toUrlQueryString(prefix + "name" + suffix));
        }

        // add `geburt` to the URL query string
        if (getGeburt() != null) {
            joiner.add(getGeburt().toUrlQueryString(prefix + "geburt" + suffix));
        }

        // add `geschlecht` to the URL query string
        if (getGeschlecht() != null) {
            try {
                joiner.add(String.format("%sgeschlecht%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getGeschlecht()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `lokalisierung` to the URL query string
        if (getLokalisierung() != null) {
            try {
                joiner.add(String.format("%slokalisierung%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getLokalisierung()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `vertrauensstufe` to the URL query string
        if (getVertrauensstufe() != null) {
            try {
                joiner.add(String.format("%svertrauensstufe%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getVertrauensstufe()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `auskunftssperre` to the URL query string
        if (getAuskunftssperre() != null) {
            try {
                joiner.add(String.format("%sauskunftssperre%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getAuskunftssperre()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `revision` to the URL query string
        if (getRevision() != null) {
            try {
                joiner.add(String.format("%srevision%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getRevision()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        return joiner.toString();
    }

}
