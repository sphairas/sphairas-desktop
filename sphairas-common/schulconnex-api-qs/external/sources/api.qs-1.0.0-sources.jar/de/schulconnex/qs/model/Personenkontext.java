package de.schulconnex.qs.model;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.StringJoiner;
import org.apache.commons.lang.StringUtils;

/**
 * Der Personenkontext gibt an, in welcher Rolle der Dienst von nutzenden
 * Personen in Anspruch genommen wird. Der Personenkontext umfasst neben der
 * Rolle auch Informationen über die Organisation, an der diese Rolle ausgeführt
 * wird.
 */
@JsonPropertyOrder({
    Personenkontext.JSON_PROPERTY_ID,
    Personenkontext.JSON_PROPERTY_REFERRER,
    Personenkontext.JSON_PROPERTY_MANDANT,
    Personenkontext.JSON_PROPERTY_ORGANISATION,
    Personenkontext.JSON_PROPERTY_ROLLE,
    Personenkontext.JSON_PROPERTY_PERSONENSTATUS,
    Personenkontext.JSON_PROPERTY_JAHRGANGSSTUFE,
    Personenkontext.JSON_PROPERTY_SICHTFREIGABE,
    Personenkontext.JSON_PROPERTY_LOESCHUNG,
    Personenkontext.JSON_PROPERTY_REVISION
})
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2024-04-05T18:25:56.866712+02:00[Europe/Berlin]", comments = "Generator version: 7.4.0")
public class Personenkontext extends SchulconnexEntitaet {

    public static final String JSON_PROPERTY_ORGANISATION = "organisation";
    private Organisation organisation;

    public static final String JSON_PROPERTY_ROLLE = "rolle";
    private String rolle;

    public static final String JSON_PROPERTY_PERSONENSTATUS = "personenstatus";
    private String personenstatus;

    public static final String JSON_PROPERTY_JAHRGANGSSTUFE = "jahrgangsstufe";
    private String jahrgangsstufe;

    public static final String JSON_PROPERTY_SICHTFREIGABE = "sichtfreigabe";
    private String sichtfreigabe;

    public static final String JSON_PROPERTY_LOESCHUNG = "loeschung";
    private Loeschung loeschung;

    public Personenkontext() {
    }

    public Personenkontext id(String id) {
        this.id = id;
        return this;
    }

    public Personenkontext referrer(String referrer) {
        this.referrer = referrer;
        return this;
    }

    public Personenkontext mandant(String mandant) {
        this.mandant = mandant;
        return this;
    }

    public Personenkontext organisation(Organisation organisation) {
        this.organisation = organisation;
        return this;
    }

    /**
     * Get organisation
     *
     * @return organisation
     *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_ORGANISATION)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public Organisation getOrganisation() {
        return organisation;
    }

    @JsonProperty(JSON_PROPERTY_ORGANISATION)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setOrganisation(Organisation organisation) {
        this.organisation = organisation;
    }

    public Personenkontext rolle(String rolle) {
        this.rolle = rolle;
        return this;
    }

    /**
     * String (Code) - Rolle der Person innerhalb der Organisation. Referenz auf
     * einen Code der Codeliste 11.3 Rolle.
     *
     * @return rolle
     *
     */
    @javax.annotation.Nonnull
    @JsonProperty(JSON_PROPERTY_ROLLE)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public String getRolle() {
        return rolle;
    }

    @JsonProperty(JSON_PROPERTY_ROLLE)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public void setRolle(String rolle) {
        this.rolle = rolle;
    }

    public Personenkontext personenstatus(String personenstatus) {
        this.personenstatus = personenstatus;
        return this;
    }

    /**
     * String (Code) - Status, den eine Person in einer Organisation in Bezug
     * auf eine bestimmte Rolle hat. Referenz auf einen Code der Codeliste 11.1
     * Personenstatus.
     *
     * @return personenstatus
     *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_PERSONENSTATUS)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public String getPersonenstatus() {
        return personenstatus;
    }

    @JsonProperty(JSON_PROPERTY_PERSONENSTATUS)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setPersonenstatus(String personenstatus) {
        this.personenstatus = personenstatus;
    }

    public Personenkontext jahrgangsstufe(String jahrgangsstufe) {
        this.jahrgangsstufe = jahrgangsstufe;
        return this;
    }

    /**
     * String (Code) - Jahrgangsstufe, die eine Person in der Organisation in
     * einer bestimmten Rolle besucht. Referenz auf Code der Codeliste 11.6
     * Jahrgangsstufe.
     *
     * @return jahrgangsstufe
     *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_JAHRGANGSSTUFE)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public String getJahrgangsstufe() {
        return jahrgangsstufe;
    }

    @JsonProperty(JSON_PROPERTY_JAHRGANGSSTUFE)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setJahrgangsstufe(String jahrgangsstufe) {
        this.jahrgangsstufe = jahrgangsstufe;
    }

    public Personenkontext sichtfreigabe(String sichtfreigabe) {
        this.sichtfreigabe = sichtfreigabe;
        return this;
    }

    /**
     * String (Code) - Gibt an, ob dieser Personenkontext aufgrund der Freigabe
     * durch eine andere Organisation sichtbar ist. Ist
     * \&quot;sichtfreigabe\&quot; nicht gesetzt, so entspricht das dem Wert
     * \&quot;nein\&quot;. Der Wert von Sichtfreigabe ist Boolean nach
     * Codetabelle 11.7 Boolean.
     *
     * @return sichtfreigabe
     *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_SICHTFREIGABE)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public String getSichtfreigabe() {
        return sichtfreigabe;
    }

    @JsonProperty(JSON_PROPERTY_SICHTFREIGABE)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setSichtfreigabe(String sichtfreigabe) {
        this.sichtfreigabe = sichtfreigabe;
    }

    public Personenkontext loeschung(Loeschung loeschung) {
        this.loeschung = loeschung;
        return this;
    }

    /**
     * Get loeschung
     *
     * @return loeschung
     *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_LOESCHUNG)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public Loeschung getLoeschung() {
        return loeschung;
    }

    @JsonProperty(JSON_PROPERTY_LOESCHUNG)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setLoeschung(Loeschung loeschung) {
        this.loeschung = loeschung;
    }

    public Personenkontext revision(String revision) {
        this.revision = revision;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Personenkontext personenkontext = (Personenkontext) o;
        return Objects.equals(this.id, personenkontext.id)
                && Objects.equals(this.referrer, personenkontext.referrer)
                && Objects.equals(this.mandant, personenkontext.mandant)
                && Objects.equals(this.organisation, personenkontext.organisation)
                && Objects.equals(this.rolle, personenkontext.rolle)
                && Objects.equals(this.personenstatus, personenkontext.personenstatus)
                && Objects.equals(this.jahrgangsstufe, personenkontext.jahrgangsstufe)
                && Objects.equals(this.sichtfreigabe, personenkontext.sichtfreigabe)
                && Objects.equals(this.loeschung, personenkontext.loeschung)
                && Objects.equals(this.revision, personenkontext.revision);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id,
                referrer,
                mandant,
                organisation,
                StringUtils.upperCase(rolle),
                StringUtils.upperCase(personenstatus),
                jahrgangsstufe,
                StringUtils.upperCase(sichtfreigabe),
                loeschung,
                revision);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Personenkontext {\n");
        sb.append("    id: ").append(toIndentedString(id)).append("\n");
        sb.append("    referrer: ").append(toIndentedString(referrer)).append("\n");
        sb.append("    mandant: ").append(toIndentedString(mandant)).append("\n");
        sb.append("    organisation: ").append(toIndentedString(organisation)).append("\n");
        sb.append("    rolle: ").append(toIndentedString(rolle)).append("\n");
        sb.append("    personenstatus: ").append(toIndentedString(personenstatus)).append("\n");
        sb.append("    jahrgangsstufe: ").append(toIndentedString(jahrgangsstufe)).append("\n");
        sb.append("    sichtfreigabe: ").append(toIndentedString(sichtfreigabe)).append("\n");
        sb.append("    loeschung: ").append(toIndentedString(loeschung)).append("\n");
        sb.append("    revision: ").append(toIndentedString(revision)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

    /**
     * Convert the instance into URL query string.
     *
     * @return URL query string
     */
    public String toUrlQueryString() {
        return toUrlQueryString(null);
    }

    /**
     * Convert the instance into URL query string.
     *
     * @param prefix prefix of the query string
     * @return URL query string
     */
    public String toUrlQueryString(String prefix) {
        String suffix = "";
        String containerSuffix = "";
        String containerPrefix = "";
        if (prefix == null) {
            // style=form, explode=true, e.g. /pet?name=cat&type=manx
            prefix = "";
        } else {
            // deepObject style e.g. /pet?id[name]=cat&id[type]=manx
            prefix = prefix + "[";
            suffix = "]";
            containerSuffix = "]";
            containerPrefix = "[";
        }

        StringJoiner joiner = new StringJoiner("&");

        // add `id` to the URL query string
        if (getId() != null) {
            try {
                joiner.add(String.format("%sid%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getId()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `referrer` to the URL query string
        if (getReferrer() != null) {
            try {
                joiner.add(String.format("%sreferrer%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getReferrer()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `mandant` to the URL query string
        if (getMandant() != null) {
            try {
                joiner.add(String.format("%smandant%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getMandant()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `organisation` to the URL query string
        if (getOrganisation() != null) {
            joiner.add(getOrganisation().toUrlQueryString(prefix + "organisation" + suffix));
        }

        // add `rolle` to the URL query string
        if (getRolle() != null) {
            try {
                joiner.add(String.format("%srolle%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getRolle()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `personenstatus` to the URL query string
        if (getPersonenstatus() != null) {
            try {
                joiner.add(String.format("%spersonenstatus%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getPersonenstatus()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `jahrgangsstufe` to the URL query string
        if (getJahrgangsstufe() != null) {
            try {
                joiner.add(String.format("%sjahrgangsstufe%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getJahrgangsstufe()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `sichtfreigabe` to the URL query string
        if (getSichtfreigabe() != null) {
            try {
                joiner.add(String.format("%ssichtfreigabe%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getSichtfreigabe()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `loeschung` to the URL query string
        if (getLoeschung() != null) {
            joiner.add(getLoeschung().toUrlQueryString(prefix + "loeschung" + suffix));
        }

        // add `revision` to the URL query string
        if (getRevision() != null) {
            try {
                joiner.add(String.format("%srevision%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getRevision()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        return joiner.toString();
    }

}
