package de.schulconnex.qs.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.StringJoiner;

/**
 * SanisExceptionDetails
 */
@JsonPropertyOrder({
    SanisExceptionDetails.JSON_PROPERTY_CODE,
    SanisExceptionDetails.JSON_PROPERTY_SUBCODE,
    SanisExceptionDetails.JSON_PROPERTY_TITEL,
    SanisExceptionDetails.JSON_PROPERTY_BESCHREIBUNG
})
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2024-04-05T18:25:56.866712+02:00[Europe/Berlin]", comments = "Generator version: 7.4.0")
public class SanisExceptionDetails {

    public static final String JSON_PROPERTY_CODE = "code";
    private String code;

    public static final String JSON_PROPERTY_SUBCODE = "subcode";
    private String subcode;

    public static final String JSON_PROPERTY_TITEL = "titel";
    private String titel;

    public static final String JSON_PROPERTY_BESCHREIBUNG = "beschreibung";
    private String beschreibung;

    public SanisExceptionDetails() {
    }

    public SanisExceptionDetails code(String code) {
        this.code = code;
        return this;
    }

    /**
     * Get code
     *
     * @return code
  *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_CODE)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public String getCode() {
        return code;
    }

    @JsonProperty(JSON_PROPERTY_CODE)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setCode(String code) {
        this.code = code;
    }

    public SanisExceptionDetails subcode(String subcode) {
        this.subcode = subcode;
        return this;
    }

    /**
     * Get subcode
     *
     * @return subcode
  *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_SUBCODE)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)

    public String getSubcode() {
        return subcode;
    }

    @JsonProperty(JSON_PROPERTY_SUBCODE)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setSubcode(String subcode) {
        this.subcode = subcode;
    }

    public SanisExceptionDetails titel(String titel) {

        this.titel = titel;
        return this;
    }

    /**
     * Get titel
     *
     * @return titel
  *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_TITEL)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)

    public String getTitel() {
        return titel;
    }

    @JsonProperty(JSON_PROPERTY_TITEL)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setTitel(String titel) {
        this.titel = titel;
    }

    public SanisExceptionDetails beschreibung(String beschreibung) {

        this.beschreibung = beschreibung;
        return this;
    }

    /**
     * Get beschreibung
     *
     * @return beschreibung
  *
     */
    @javax.annotation.Nullable
    @JsonProperty(JSON_PROPERTY_BESCHREIBUNG)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)

    public String getBeschreibung() {
        return beschreibung;
    }

    @JsonProperty(JSON_PROPERTY_BESCHREIBUNG)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setBeschreibung(String beschreibung) {
        this.beschreibung = beschreibung;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SanisExceptionDetails sanisExceptionDetails = (SanisExceptionDetails) o;
        return Objects.equals(this.code, sanisExceptionDetails.code)
                && Objects.equals(this.subcode, sanisExceptionDetails.subcode)
                && Objects.equals(this.titel, sanisExceptionDetails.titel)
                && Objects.equals(this.beschreibung, sanisExceptionDetails.beschreibung);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, subcode, titel, beschreibung);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class SanisExceptionDetails {\n");
        sb.append("    code: ").append(toIndentedString(code)).append("\n");
        sb.append("    subcode: ").append(toIndentedString(subcode)).append("\n");
        sb.append("    titel: ").append(toIndentedString(titel)).append("\n");
        sb.append("    beschreibung: ").append(toIndentedString(beschreibung)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

    /**
     * Convert the instance into URL query string.
     *
     * @return URL query string
     */
    public String toUrlQueryString() {
        return toUrlQueryString(null);
    }

    /**
     * Convert the instance into URL query string.
     *
     * @param prefix prefix of the query string
     * @return URL query string
     */
    public String toUrlQueryString(String prefix) {
        String suffix = "";
        String containerSuffix = "";
        String containerPrefix = "";
        if (prefix == null) {
            // style=form, explode=true, e.g. /pet?name=cat&type=manx
            prefix = "";
        } else {
            // deepObject style e.g. /pet?id[name]=cat&id[type]=manx
            prefix = prefix + "[";
            suffix = "]";
            containerSuffix = "]";
            containerPrefix = "[";
        }

        StringJoiner joiner = new StringJoiner("&");

        // add `code` to the URL query string
        if (getCode() != null) {
            try {
                joiner.add(String.format("%scode%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getCode()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `subcode` to the URL query string
        if (getSubcode() != null) {
            try {
                joiner.add(String.format("%ssubcode%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getSubcode()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `titel` to the URL query string
        if (getTitel() != null) {
            try {
                joiner.add(String.format("%stitel%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getTitel()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        // add `beschreibung` to the URL query string
        if (getBeschreibung() != null) {
            try {
                joiner.add(String.format("%sbeschreibung%s=%s", prefix, suffix, URLEncoder.encode(String.valueOf(getBeschreibung()), "UTF-8").replaceAll("\\+", "%20")));
            } catch (UnsupportedEncodingException e) {
                // Should never happen, UTF-8 is always supported
                throw new RuntimeException(e);
            }
        }

        return joiner.toString();
    }

}
