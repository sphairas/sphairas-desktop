package de.schulconnex.qs.model;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nullable;

/**
 *
 * @author boris
 */
public abstract class SchulconnexEntitaet {

    public static final String JSON_PROPERTY_ID = "id";
    public static final String JSON_PROPERTY_REFERRER = "referrer";
    public static final String JSON_PROPERTY_MANDANT = "mandant";
    public static final String JSON_PROPERTY_REVISION = "revision";
    protected String id;
    protected String referrer;
    protected String mandant;
    protected String revision;
    protected final Map<String, Object> any = new HashMap<>();

    protected SchulconnexEntitaet() {
    }

    /**
     * String (UTF-8) - ID der Person. Wird vom SchulConnectX Server vergeben
     * ist eindeutig. Dieses Attribut ist unveränderbar (immutable).
     *
     * @return id
     *
     */
    @Nullable
    @JsonProperty(value = JSON_PROPERTY_ID)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public String getId() {
        return id;
    }

    @JsonProperty(value = JSON_PROPERTY_ID)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public void setId(String id) {
        this.id = id;
    }

    /**
     * String (UTF-8) - Die optionale Identifikations-ID einer Person muss
     * innerhalb eines Quellsystems eindeutig sein (z. B. die einheitliche
     * Personalnummer des Landes Niedersachsen, falls vergeben).
     *
     * @return referrer
     *
     */
    @Nullable
    @JsonProperty(value = JSON_PROPERTY_REFERRER)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public String getReferrer() {
        return referrer;
    }

    @JsonProperty(value = JSON_PROPERTY_REFERRER)
    @JsonInclude(value = JsonInclude.Include.USE_DEFAULTS)
    public void setReferrer(String referrer) {
        this.referrer = referrer;
    }

    /**
     * String (UTF-8) - ID des Mandanten, dem die Personen zugeordnet ist. Wird
     * vom SchulConnectX Server vergeben und ist eindeutig.
     *
     * @return mandant
     *
     */
    @Nullable
    @JsonProperty(value = JSON_PROPERTY_MANDANT)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public String getMandant() {
        return mandant;
    }

    @JsonProperty(value = JSON_PROPERTY_MANDANT)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public void setMandant(String mandant) {
        this.mandant = mandant;
    }

    /**
     * String (UTF-8) - Revision der Person. Wird vom SchulConnectX Server mit
     * der Erstellung des Datensatzes sowie Aktualisierung generiert. Dieser
     * Wert kann nicht von Quellsystemen oder Diensten gesetzt werden.
     *
     * @return revision
     *
     */
    @Nullable
    @JsonProperty(value = JSON_PROPERTY_REVISION)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public String getRevision() {
        return revision;
    }

    @JsonProperty(value = JSON_PROPERTY_REVISION)
    @JsonInclude(value = JsonInclude.Include.ALWAYS)
    public void setRevision(String revision) {
        this.revision = revision;
    }

    @JsonAnyGetter
    public Map<String, Object> getAny() {
        return any;
    }

    @JsonAnySetter
    public void setAny(String name, Object value) {
        this.any.put(name, value);
    }

}
